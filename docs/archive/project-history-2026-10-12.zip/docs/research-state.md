# Research State

## 2026-10-12 — P4.19 matched execution references complete; retain policy

The app now collects full regular sessions and publishes a separate reference audit against pinned,
hash-verified governed raw daily histories. Thirty sessions qualified for retrospective diagnostics;
34 order windows + 30 sessions were verified identical in ClickHouse and retained source evidence.
This is a scoped audit, not continuous intraday research admission or raw-tape certification.

The frozen comparison includes **27 orders / seven ETFs / five sessions**. Actual paper-fill signed
cost is **1.185 bps against routed TWAP**, 3.769 bps against daily close and 9.471 bps against the
IB filtered session-VWAP estimate, before fees. Original TWAP is 1.228 bps; original and routed dates
match for all included orders. Close results span -6.436 to 31.268 bps when omitting one session.
**Retain the execution policy.** Reference prices are not achievable alternative fills, and this small
paper sample cannot rank styles. Corporate-action vintage, provider-volume units and raw-close
source differences remain explicit. [Full findings](execution-reference-findings.md).

Eighteen filled orders lack complete execution details; missing windows and USO/DBB contract gaps
remain explicit. No prices or fills were inferred. Frozen root:
`var/research/execution-references-20261012-v1/`; exact replay passed. Focused tests: 100 passed,
one disposable-ClickHouse skip; seven final analysis checks and Ruff passed. Actual publication
verification is separate from the skipped test. App/analytics/IB are healthy; collector gaps remain
visible. Before/after control state and counts match: revision 5, F3 100% paper, no pending allocation,
270 orders / 45 filled. No orders were submitted by this work.

Next research delivery: P4.16d candidate inventory, taxonomy and comparable ETF groups. Pair scaling
with the requested P6.15 measured worker-resource review. P8 remains the execution-contract
prerequisite for the conditional FR25 paper pilot; the alpha variant remains at zero allocation.

## 2026-10-11 — P4.19a automatic benchmark collection deployed

The operator authorized the next prerequisite. The [app-owned collector](execution-benchmark-collection.md)
now scans paper orders independently of the blotter, retains original/routed windows and immutable
attempt evidence, and publishes validated observations and explicit coverage. At 14:28 UTC, **34
windows were hash-verified against their source captures and identical ClickHouse documents**, covering
30 paper TWAP orders. Two other explicit windows are USO/DBB, outside the configured IB contract
universe; ten legacy TWAP orders have no explicit window. No missing window or execution detail was
inferred. The initial IB 2188 rejection of complete older historical responses was corrected; failed
attempts are retained and natural retries recovered the supported windows.

This delivers the collection mechanism, not the entire timing comparison. Captures carry
`research_approved: false`; trading-time raw-unit, matched raw-close and full-session VWAP qualification
remain P4.19a prerequisites. Bar volume/WAP is retained, but order-window bars are not full-session
evidence. Preserve the earlier frozen P4.19 audit. Next: qualify those input contracts and publish a
versioned matched cohort before running a new timing study. P6.15 and the substantial ETF-universe
programme remain in the plan; no worker-resource setting or universe admission changed here.

Validation: 96 focused tests passed, one explicit disposable-ClickHouse test skipped, Ruff passed;
deployment publication/readback verified against actual ClickHouse. Receipts are
`var/research/benchmark-collection-20261011-before.json` and `...-after.json`. Paper control state is
unchanged at revision 5, F3 100%, no pending allocation; order counts remain 270 total / 45 filled.

## 2026-10-11 — P4.19 coverage audit; worker resource review queued

At the operator's request, moved to P4.19 after recording the agreed plan. The frozen
[execution-timing audit](execution-timing-findings.md) contains 270 paper order records, 45 filled
orders (42 TWAP), 27 complete execution histories and zero published benchmark documents. Of 42 TWAP
orders, 32 have explicit windows. No supported cost comparison exists; slippage remains unavailable.
The audit is complete and reproducible, but P4.19's timing comparison is blocked. Registered P4.19a
app-owned collection/publication, including matched raw-close and intraday traded-value/volume evidence.
No inferred VWAP, provider-archive study, execution-style ranking or policy change. 25 focused tests
and Ruff pass; offline verification preserves the frozen files.

The operator also requested a future fix for Docker-constrained research concurrency. Registered
P6.15 in the Kanban and [calculation-performance plan](calculation-performance.md): benchmark actual
working sets and host-native/container alternatives before changing the fixed 4 GiB/run rule.
Read-only inspection confirms all 16 CPUs are visible to Docker, but its 15.39 GiB limit produces
three LEAN workers; the host has 31.55 GiB and most Python calculation processes already run there.
ClickHouse memory is not a shared research-worker heap. No runtime or Docker settings changed.

## 2026-10-11 — Operator accepted priorities and substantial ETF expansion

The operator accepted the second-review recommendations and requested a much larger tradable ETF
universe. The [research plan](signal-decay-and-alpha-plan.md) records the minimum paper execution
contract, conditional 5% FR25 / 95% F3 paper preview, retained execution-cost evidence, and staged
P4.16d expansion through inventory, audited admission, app/execution readiness and full-pool research.
It also retains horizon-specific incremental alpha tests and fill-based TP/SL requirements. This is
planning only: no new instrument admission, allocation or order. The first expansion deliverable is
the candidate inventory, dated taxonomy and data/contract gap matrix; it is not blocked on having
already published the expanded pool.

## 2026-10-11 — Second review: corrected evidence and paper-allocation decision

This entry supersedes conflicting P4.17 conclusions below; older entries remain the historical record.
The [complete review](strategy-review-2026-10-11.md) reconciles the supplied DOCX against the code,
repairs the remaining defects, and records the evidence and research recommendations.

- Corrected FR25 versus 5% monthly Alpha101: **13.091% versus 12.988% CAGR**, Sharpe **1.193 versus
  1.182**, max drawdown **−8.656% versus −8.253%**, on 2021-01-04–2026-10-08 at 5 bp. The tilt
  trails in return and Sharpe in all six cost/delay scenarios; the paired six-month interval spans zero.
  No incremental edge is established. Twelve replays, 70 app/research monthly decisions with exact
  holdings/cash/fee parity, and native LEAN parity for both arms: `strategy-review-20261011-v3`.
- Corrected screen: **0/16** standalone passes; matched-payoff tilt passes **4/16, 3/16, 3/16** at
  5/10/20%, not the previous 12/12/5. Full-pool IC no longer finances a tiny overlay. Zero-cost mappings
  need positive information. Screen/tilt verification is read-only, and audited raw inputs reach the app.
- The fixed-through-2022 FR25 comparison is **retraining sensitivity**, not a hindsight test. Daily event
  counts are totals over the study, not annual frequencies. Nonsignificance is not equivalence.
- Paper-first confirmed by operator. M1/14, FR25 and Alpha101 stay monitored; their 14-ETF execution
  contract remains incomplete. IB Gateway and reconciliation were initially blocked, then passed after operator login. Shared UI/backend
  gating now explains these blockers. F3 retains 100% paper strategy capital at revision 5; no orders.
- **P4.18 executed and rejected for this fixed rule.** A preregistered 10% volatility target / 63-session
  monthly rule earned 10.170% CAGR, 1.113 Sharpe and −8.719% maxDD, versus FR25's 13.091% / 1.193 /
  −8.656%. A matched constant scale performed better. All six scenarios fail the risk/return limits;
  18 replays and native parity completed in `volatility-target-20261011-v1`. No tuning or promotion.

Next: minimum verified 14-ETF paper contract (P8.1–P8.5), retained execution evidence (P4.19), and
comparable audited ETF breadth (P4.16d), followed by a preregistered horizon/peer-group alpha test.
The operator manually confirmed likely XLE/XLB trading permission; that is recorded and is not
treated as a denial. Independent FR25 model/input binding, mixed-universe allocation and the
execution contracts remain the relevant blockers. Paper API/reconciliation now pass, with XLE/XLB
contract identities independently verified after login.
TP/SL should use explicit risk units, actual fill attribution and gap/session rules; it is not an assumed
cure for weak signals. 309 focused tests pass; changed Python passes Ruff. App refresh is recorded in log.


## 2026-10-11 — Peer review found five real defects in the Alpha101 work; all confirmed, fixed, re-run

A second agent reviewed the P4.17 screen, the tilt studies and the deployed overlay. Every finding was reproduced
against the code before anything changed, and **all five were real**:

1. **Hold semantics.** The daily and exit arms — *and both of their controls* — re-submitted the same target
   vector every session, which rebalances back to the target weights as prices drift instead of holding shares.
   The exit study's HOLD arm wrote 1,448 decision rows where the monthly strategy has 70, so the studies measured
   a different trading process from the strategy being compared.
2. **Unreachable re-entry.** The exit-and-re-enter branch sat behind an `elif held:` guard that the exit had just
   emptied, so the arm could never re-enter; its diagnostic counted re-tilts of a position still on.
3. **Look-ahead in the P&L exits.** `should_exit` read the close of the same session whose target it produced.
4. **Alpha 43.** Every historical volume was divided by the **latest** rolling average dollar volume instead of
   each date's own: 0.450000 (published formula) against 0.600000 (implementation). An audit of the other fifteen
   alphas confirmed 43 was the only defective one — and it is the one the monitored strategy runs.
5. **Rank IC ties.** Tied values took ordinal ranks in ticker order, so identical signal/return pairs scored
   0.657143 versus 0.371429 under relabelling, and 0.371429 against 0.441367 for textbook mid-rank Spearman.

**Fixes.** `rolling_adv` gives alpha 43 each date's own window; `midranks` gives rank IC averaged ties; both
studies and both controls emit a decision row **only when the target vector changes**, so a held position is held;
re-entry is evaluated when no tilt is held; the P&L exits read only closes strictly before the session they trade,
with the entry base taken from the entry session's own close. Six regression tests pin each defect, including the
published-formula equality for alpha 43 and label-invariance for rank IC. The audit also cleared the other three
`adv20` users (7, 21, 43's siblings) and `signal_decay.rank_ic`, which already averaged ties.

**Re-runs.** Artifacts were invalidated rather than annotated, so the affected studies were re-frozen under **v2**
roots that record the correction in their protocols, with the chain aligned (the measurement points at the
corrected screen, the surface at the corrected replay, the daily study at the corrected surface). The v1 roots are
kept as the historical record and marked superseded. The monitored strategy recalculated under revision
`c519e86cd455` with **0 parity differences** on all five M1-family runs; its published figures barely move
(11.17%/1.1025/−20.28% against 11.18%/1.103/−20.28%) because one alpha of sixteen enters a rank average.

**Corrected conclusions.** *Withdrawn:* "exiting early is worse than holding" — with a working re-entry, FR25's
best in-sample arm on total return, CAGR and Sharpe is X = 5% with flip-exit-and-re-enter (105.4% / 13.32% /
1.212 at 53.2bp) against X = 5% held (105.0% / 13.28% / 1.207 / **1.609** Calmar at 41.0bp), so it buys ~+0.4pp of
net return for ~+12bp/yr of cost; plain exiting without re-entry is still clearly worse (103.9% at 43.5bp), and the
SOTA still prefers holding outright. *Qualified:* "5% HOLD is the best configuration" — it remains best on Calmar
and drawdown, but not on the other three metrics. *Unchanged:* nothing is statistically established (0 of 20
contrasts), high frequency destroys value (the 300% band reproduces the monthly arm at 41.6bp / 103.9%), and the
screen still rejects the family (0 pass, 15 reject, 1 insufficient).

**The monitored strategy keeps the recipe the operator chose**, still with `promotion_eligible=False`,
`execution_enabled=False` and the 14-ETF execution-contract reason. Switching to the corrected in-sample best is a
one-line parameter change and an operator decision; it is not made here because the advantage has no statistical
support. Full record: [alpha101-peer-review-corrections.md](alpha101-peer-review-corrections.md).

## 2026-10-11 — The Alpha101 family tilt is now a monitored strategy

The measured best configuration (5% family tilt, held from each monthly decision to the next) is built into a
registered strategy and added to the monitored set: **`research_fr25_alpha_tilt_5_v1` — "FR25 + 5% Alpha101
family tilt"**, USD accounting, calculated by the app's own services with the standard full spec sheet.

- **Deployed as a real overlay.** `alpha101_tilt_overlay.Alpha101FamilyTiltOverlay` ranks the names the book
  already holds by the equal-weight mean of the sixteen registered alphas' rank scores, moves 5% of NAV from the
  bottom of that ranking to the top, and shrinks as a whole so no name breaches the 45% cap or goes negative. It
  is appended **last** in the FR25 chain and preserves the symbol set and gross that the defensive fallback
  protects. The catalog validates the recipe against one registered parameter set, so a strategy cannot be
  registered with a budget, alpha list or cap that was never measured.
- **Parity verified.** LEAN and the reference engine run the same code; the native attempt passed with **0
  differences**, and a test asserts the deployed rule reproduces the measured study rule exactly (that test
  caught one missing diagnostic during the build).
- **Posture.** `promotion_eligible=False`, `execution_enabled=False`, `allocation_ready=False` with the
  platform's own reason: *"Monitoring only; the separate 14-ETF execution contract has not been approved."*
- **Disclosure travels with the strategy.** The definition and spec-sheet diagram state that the evidence is
  **not established** — 0 of 20 family-adjusted contrasts against the untouched book, the 5% arm slightly below
  its control on total return with a better Calmar and drawdown, and the 5% budget an in-sample optimum.
- **Integration lesson worth keeping:** a new 14-candidate recipe must join the M1/14 family in five places —
  `tracked_runtime`'s family partition and its financial-input check, `m1_monitoring`'s recipe guard and its
  financial requirement, and `strategy_lifecycle`'s USD-currency and allocation-supported sets. Missing any of
  them routes the strategy through the 12-ETF pool and the model fit fails with "Training universe/order differs
  from the versioned strategy".

## 2026-10-11 — P4.17f exit rules: holding beats exiting, and half the rules never fire

Operator direction: holding to the next monthly rebalance is not optimal — remove the tilt when the signal
disappears or stops; cost is not a constraint, the objective is the optimum. Frozen study
`var/research/alpha101-tilt-exit-20261011-v1/` (protocol `db40c5e1…`): FR25 and the SOTA, 42 arms, 252 replays,
monthly entry with declared intra-month exits, **no cost filter** (arms to 84.3bp all replayed), ranked on net
outcomes. [Findings](alpha101-tilt-exit-findings.md) ·
[Report](../research/alpha101-tilt-exit-2026-10-11/index.html).

**Holding beats exiting.** FR25's best net configuration is **X = 5% held** — 104.9% total return, 13.27% CAGR,
1.204 Sharpe, 1.598 Calmar, −8.30% max drawdown, 40.9bp — and the SOTA's is **X = 10% held** — 77.3%, 10.46%,
0.922, 0.839, −12.46%, 38.3bp. Four of the six metric optima across the two books are plain HOLD arms.

**Three of the six rules are no-ops on this data, which is the direct answer to the question.** EXIT-NOSIG never
fires in 1,448 sessions because this alpha family never stops ranking the held book; the −2% stop and the +1%
take-profit never fire; the −0.5% stop fires once. At a 5–20% tilt the tilt's own weighted return does not
travel that far inside a month, so the P&L form of the idea has no traction at these sizes. What does fire is
the **flip (61 exits)**, and acting on it is worse: it forgoes the tilt's remaining edge and pays a round trip,
adding +2.4bp at X = 5% and +4.6bp at X = 10% while leaving Sharpe unchanged and Calmar lower; the re-entry
variant costs +10 to +25bp for the same or worse return.

**The mechanism:** the monthly design already rotates the tilt at the next decision — 54 flips, 2 closes and 2
opens across FR25's 70 decisions — so an early exit is an extra trade against a rotation the rebalance pays for
anyway. **Nothing is established:** 0 of 20 contrasts per book differ from the untouched book at Holm p < 0.05.

**On LEAN:** each arm is one target vector per session, which is exactly what a daily-rebalancing strategy
submits, and the replay engine's LEAN parity is already verified at 0 differences. A native algorithm would add
promotion-grade parity evidence rather than different numbers, and is the right artefact if a tilt is ever taken
toward promotion. **Next: P4.18 volatility targeting.**

## 2026-10-11 — P4.17d/P4.17e: the tilt has no high-X regime and no profitable high-frequency one

**P4.17d — the budget surface** (operator-requested): FR25 and the SOTA tilted monthly at X up to 150%, every arm
replayed irrespective of cost. `var/research/alpha101-tilt-surface-20261011-v1/` (protocol `99cd55a8…`), 16 arms,
96 replays. [Findings](alpha101-tilt-surface-findings.md).

| FR25 | Total return | CAGR | Sharpe | Calmar | Max DD | Cost |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| untouched | **106.0%** | **13.37%** | **1.218** | 1.545 | −8.66% | 41.0bp |
| X = 10% | 104.1% | 13.20% | 1.196 | **1.608** | **−8.21%** | 41.7bp |
| X = 50% | 94.9% | 12.29% | 1.059 | 1.105 | −11.12% | 51.7bp |
| X = 150% | 96.2% | 12.42% | 1.028 | 1.070 | −11.61% | 56.5bp |

**There is no higher-X regime**: on FR25 every measure degrades as the budget rises, and on the SOTA the return
peaks at 10% while every risk ratio worsens above it. **The tilt saturates at ~51% of NAV** — declared 100% gives
50.6% effective and 150% gives 50.7%, for identical cost — because one shrink factor holds every name inside the
45% cap and above zero. Cost: X ≤ 20% passes the 44.0bp ceiling, X ≥ 30% is rejected. No optimal X is declared;
the best X is an in-sample maximum.

**P4.17e — daily, threshold-triggered** (operator-requested): 1,448 sessions, X ∈ {5, 10, 20}%, band ∈ {daily,
50%, 100%, 200%, 300%} of the budget. `var/research/alpha101-tilt-daily-20261011-v1/` (protocol `725aa02b…`),
34 arms, 204 replays. [Findings](alpha101-tilt-daily-findings.md).

**Every daily arm is worse than doing nothing and costs 2–5.5× more** — FR25 daily at 5/10/20% returns 101.1% /
96.5% / 87.6% against the untouched 105.8%, with Sharpe 1.174 / 1.131 / 1.042 against 1.214, at 91.8 / 142.8 /
243.3bp; the SOTA behaves the same way. **The band works exactly as proposed, and that is the problem:** a 300%
band cuts re-tilts from 1,269 to 64 over the study (about 221 to 11 per year) and cost to 37–44bp, but fitting the 44.0bp ceiling requires a
200–300% band, where the arm trades **64–86 times a year — the monthly arm's own 70**. Daily monitoring behind a
wide deadband is the monthly tilt with extra bookkeeping, and every band arm that clears the ceiling is
statistically indistinguishable from doing nothing (intervals spanning zero, Holm p = 1.000).

**Why:** the family's information lives at the 21-session horizon (rank IC 0.05–0.075), so daily re-tilting
trades one-session noise while paying linearly in cost. A genuinely higher-frequency use would need a signal
whose information is measured at one to five sessions. **Next: P4.18 volatility targeting**, with the drawdown
question untouched by all of this.

## 2026-10-11 — P4.17c: the 10% tilt baked into the SOTA is nearly free and nearly neutral

Operator request: bake the tested alpha into the current SOTA with a 10% tilt and report return, Sharpe,
Calmar and max drawdown. Frozen study `var/research/alpha101-tilt-replay-20261011-v1/` (protocol
`bb7dba31…`), 36 replays, every arm gated before any replay. The tilt is appended **last** in the SOTA's own
overlay chain, so it ranks only what the strategy holds and keeps the symbol set and gross the defensive
fallback protects. [Findings](alpha101-tilt-replay-findings.md) ·
[Report](../research/alpha101-tilt-replay-2026-10-11/index.html).

| Arm | Total return | CAGR | Sharpe | Calmar | Max DD | Incremental cost |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| SOTA (`research_fallback_f3_v1`), untouched | 76.4% | 10.36% | 0.916 | 0.805 | −12.88% | — |
| SOTA + 10% tilt of alpha 53 | 77.0% | 10.42% | 0.913 | 0.818 | −12.75% | +2.08bp |
| SOTA + 10% family tilt | **77.5%** | **10.48%** | **0.922** | **0.840** | **−12.47%** | +1.53bp |

**Verdict: inconclusive.** Every measure moves the right way — return up 0.6–1.1pp cumulatively, Calmar up
1.6–4.3%, maximum drawdown 0.13–0.41pp better — but the annualised differences are **+0.07% and +0.12%**
with 95% intervals spanning zero at 3, 6 and 12 months and **Holm p = 1.000**. Sharpe is flat. The tilt is
**nearly free and nearly neutral**: it costs 1.5–2.1bp a year and returns 7–12bp a year.

**The gate passed all three arms before any replay:** SOTA 7.03×/35.14bp, +tilt-53 7.45×/37.23bp, +family
7.33×/36.67bp, all inside the 44.0bp ceiling — the SOTA leaves about 8.9bp of headroom and the tilt uses a
fifth of it.

**The family tilt beats the best-information single alpha at lower cost** (+0.12% for 1.53bp against +0.07%
for 2.08bp). Since alpha 53 had the strongest measured information in the screened family, this is direct
evidence that its apparent superiority was in-sample noise — the argument for tilting on the family rather
than on a selected alpha.

**A measured engine property:** the final 45% clamp runs *after* the overlay chain, so the SOTA's book can
arrive at the tilt already above the cap on 4–6 of 130 decisions. The declared single-shrink-factor rule then
shrinks the tilt to a no-op for that decision instead of pushing an over-cap name further up, so the tilt
applied on 115 of 130 decisions and the rule guarantees "never worse" rather than "always inside the cap".

**Why the effect is small, and expected:** a 10% budget moves each held weight by a few percent of NAV
against a forward rank IC of 0.05–0.075, so the expected edge is tens of basis points a year. P4.17b already
measured 20% as the point where cost binds, so there is no cheap way to make it larger.

**Next: P4.18 volatility-targeted exposure.** The SOTA stays `research_fallback_f3_v1`, monitored and
unchanged; nothing here re-tunes X, touches the 45% cap or the cash reserve, or creates promotion authority.

## 2026-10-11 — P4.17b tactical tilt: the balance is 5–10%, and the IC bar falls 100× with it

Operator proposal after P4.17 closed the mapping family: use the alphas to overweight and underweight the
holdings already in the book rather than to choose the book. Measured in
`var/research/alpha101-tilt-20261011-v1/` (protocol `1fa318f9…`), 48 declared candidates gated before any
replay. [Findings](alpha101-tilt-findings.md) ·
[Report](../research/alpha101-tilt-2026-10-11/index.html).

| Budget X | Alphas passing | Incremental turnover | Incremental cost | Worst candidate vs 3.65bp headroom |
| --- | ---: | ---: | ---: | ---: |
| **5%** | **12 of 16** | 0.00×–0.10× | **0.00–0.48bp** | **13%** |
| **10%** | **12 of 16** | 0.00×–0.34× | 0.00–1.69bp | 46% |
| 20% | 5 of 16 | 0.00×–1.03× | 0.00–5.17bp | 142% |

The headroom is derived, not assumed: the published ceiling of 44.0bp minus the monitored book's own measured
**40.35bp** drag leaves **3.65bp**. A 5% monthly tilt spends at most **0.48bp** of it. P4.17's top-six
mappings needed 44.7–76.5bp; the tilt needs a rounding error.

**The breakeven IC falls by two orders of magnitude** — 0.0061–0.0122 for the full mappings to
**0.00000–0.00008** at a 5% tilt — because it scales with turnover. The operator's "the IC threshold does not
need to be that high" is therefore a property of the design, not a relaxation: the frozen 3× margin and the
cost ceiling are applied unchanged.

**The three rejections are information failures, not cost failures**: alpha 101's tilt is inverted (−0.0749,
interval excluding zero) and alphas 23 and 12 are negative, so a long tilt points the wrong way; alpha 7
remains degenerate. That is the exact inversion of P4.17, where cost killed every alpha.

A false-pass defect — tilting a constant held cross-section on the alphabetical tie-break, then reading the
near-zero cost as a pass — was caught by the test bench and fixed before publication, with two rules frozen in
the protocol: a cross-section with fewer than two distinct values cannot rank and is left untilted, and a
candidate that never ranked the book is reported *insufficient* rather than passed. Re-measured: 29 passes
instead of 28, the ternary alphas cheaper, because days on which they express no view no longer trade.

**Next: P4.17c, the tilt replay** (equal-weight composite at 5% and 10% against the matched untilted control,
family-adjusted, judged on drawdown across episodes), then P4.18. Nothing was replayed, promoted or changed
in the monitored book.

## 2026-10-11 — P4.17 Alpha101 screen: the information is real, the turnover is not payable

The sixteen registered pure time-series alphas (6, 7, 9, 12, 21, 23, 24, 26, 35, 43, 46, 49, 51, 53,
54, 101), implemented from the paper's own formulas and screened for turnover, cost and decay
**before any portfolio result**, as the plan required. Frozen study
`var/research/alpha101-screen-20261011-v1/` (protocol `7865c485…`, pre-registered).
[Findings](alpha101-screen-findings.md) ·
[Report](../research/alpha101-screen-2026-10-11/index.html).

**Verdict: none of the sixteen clears the P4.15 gate — 15 rejected, 1 not judged (alpha 7 is a
constant).** The family closes before any portfolio work, so there is no satellite sleeve and no
modelling stage: the plan's next step was conditional on something surviving.

**The failure is turnover, not information.** Translated to this programme's monthly decision
frequency, the mappings turn over **7.62×–15.29×** against the monitored book's 8.07×, costing
**38.1bp–76.5bp** against the 44.0bp ceiling. P4.15 rejected the *daily* archetypes by 5×–46×; at
the frequency actually traded the gap is 1.0–1.9×. Only **alpha 21** is inside the ceiling (38.1bp,
at 70% coverage) and it fails on information (IC margin 2.22× against the required 3×).

**What the programme gains is the information measurement.** At 21 sessions alpha 53 shows rank IC
**+0.0747** with a 95% interval [+0.0016, +0.1522] and alpha 26 **+0.0572** with [+0.0106, +0.1052] —
both excluding zero — while alpha 101 shows **−0.0749** with [−0.1313, −0.0140], i.e. real but
*inverted* information. This is the first evidence here that a simple published formula carries
measurable forward rank IC on this universe.

**Two disclosures.** The paper defines `adv{d}` as average daily *dollar* volume while `volume` is
share volume, so alpha 7's `adv20 < volume` never holds and the formula collapses to its constant
branch as published — reported, not repaired. And a first-run wiring defect was found by inspecting
the output: a candidate with no measurable IC was judged against the programme reference IC, so alpha
7 was reported as passing with a 102.77× margin. Two rules were added before publication and frozen
in the protocol: a cross-section with fewer than two distinct values cannot rank and forms no mapping,
and a candidate with no measurable IC is reported *insufficient* and never passed on the reference IC.
Pre-correction 1 pass / 15 reject; post-correction 0 pass / 15 reject / 1 insufficient.

**Next: P4.18 volatility-targeted exposure**, with a matched-average-exposure control and the P4.15
gate first. A lower-turnover use of the surviving information would be a different, declared study.

## 2026-10-11 — P4.16b hierarchical construction: the operator's rule works, risk is untouched

Operator-proposed follow-up to P4.16: a class must **qualify** (at least one member above
the pooled control's 126-session momentum gate) before it can be chosen, the top K
qualifying classes share the budget equally, and each picks its best two names. Frozen
study `var/research/hierarchical-construction-20261011-v1/` (protocol `af9bb329…`), gated
by P4.15 before any replay. **Post-hoc on the inspected sample.**
[Findings](hierarchical-construction-findings.md).

| Arm | CAGR | Sharpe | Calmar | Max DD | Cost | Mean names |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| CP — published pooled control | 11.92% | **1.106** | **1.435** | **−8.31%** | 43.0bp | 5.19 |
| POOL — construction-matched pooled | 9.50% | 0.754 | 0.455 | −20.89% | 45.3bp | 5.39 |
| **HIER-K2** — top 2 classes | **15.07%** | 0.941 | 0.680 | −22.18% | 45.2bp | **2.91** |
| HIER-K3 — top 3 classes | 13.44% | 0.938 | 0.640 | −21.01% | **40.0bp** | 4.17 |

**The mechanism works exactly as proposed.** Neither arm held a fixed-income instrument in
any month of 2022; bonds are chosen 13% of the time under K=2 against 46% pooled, and one
decision was entirely cash because no class qualified. Both are regression tests. **K=3
reverses part of it**: with three slots fixed income is chosen 64% of the time, more often
than pooled.

**The return effect is the largest measured here and still not established.** HIER-K2 is
**+5.32pp annualised** against the matched pooled control with a 95% interval excluding zero
at 3, 6 and 12 months ([+0.69%, +10.41%] at 6m), and both risk ratios improve against that
control — but the family-adjusted Holm p is **0.164**, so under the frozen rule it is
inconclusive.

**Risk is orthogonal.** HIER-K2 holds 2.91 names with two 45% positions; its drawdown
(−22.18%) is *worse* than the diversified arm it beats on return and far worse than CP's
(−8.31%), and its Sharpe (0.941) is below CP's (1.106). This reproduces P4.16's conclusion
from the other direction: a better selection rule does not substitute for the exposure
rule. **Parked at the operator's request:** the class question is probably not answerable at
this granularity, so P4.16c is deferred behind P4.16d (granular classes on a wider universe).
**Gate:** K=3 passes at 40.7bp implied, cheaper than the pooled control's 43.6bp; K=2 is a
boundary case at 45.5bp. No promotion, no monitoring or allocation change.

## 2026-10-10 — P4.16 sleeve construction: the fallback matters more than the partition

Does within-sleeve selection beat the pooled top-six over fourteen heterogeneous
instruments? Frozen study in `var/research/sleeve-construction-20261010-v1/` (protocol
`dc73d46d…`), screened by the P4.15 gate before any replay.
[Findings](sleeve-construction-findings.md).

| Arm | CAGR | Sharpe | Calmar | Max DD | Turnover | Cost |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| CP — published pooled control | 11.92% | **1.106** | **1.435** | **−8.31%** | 8.59× | 43.0bp |
| POOL — construction-matched pooled | 9.50% | 0.754 | 0.455 | −20.89% | 9.05× | 45.3bp |
| SLV-COMP — composition budgets | 10.89% | 0.792 | 0.697 | −15.64% | 9.24× | 46.2bp |
| SLV-EQ — equal budgets | **12.00%** | 0.983 | 0.705 | −17.02% | 6.64× | 33.2bp |

1. **Sleeve construction is directionally better than pooled selection under a matched
   construction but not established.** +1.39pp / +2.50pp of CAGR with 5.2pp / 3.9pp less
   maximum drawdown, yet all six contrasts have 95% intervals spanning zero at 3/6/12
   months with Holm p = 1.000. The pooled cross-section is acceptable and not shown worse —
   the answer P4.17 needed.
2. **The published control's advantage is its defensive-cash fallback, not its pooling.**
   The construction-matched arm makes the same decision on **119 of 130** days; all 11
   differences are fallback days, with zero weight-only differences. The entire gap (CAGR
   11.92% vs 9.50%, drawdown −8.31% vs −20.89%, mean invested 86.6% vs 95.0%) is that one
   contract — and P4.14's FR25-versus-CP contrast is unaffected because both arms share it.
   **Qualified by an episode attribution:** all seven evaluation-window episodes are 2022
   (+13.69 log points, of which **+8.94 is a single month** and +3.96 a compounding tail),
   while **all four pre-2021 episodes are net negative (−2.18pp over five years)**, and
   within 2022 the rule lost 2.92pp de-risking too early. The value is a **one-episode
   statistic from one bear market**; only the drawdown property plausibly generalises.
   Receipt: `var/research/sleeve-construction-20261010-v1/followup/fallback-episodes.json`.

Also measured: composition budgets hold `DBC` and `GLD` in **all 70** evaluation decisions
(36/70 pooled) — for two of four sleeves, within-sleeve selection is permanent allocation —
and budgets constrain selection, not realised weights. The P4.15 gate passes equal budgets
at 34.0bp and records composition budgets as a boundary case at 46.8bp.

## 2026-10-10 — P4.15 turnover gate: Alpha101's daily archetypes cannot pay for themselves

The standing pre-test every later item must clear. Thresholds and usage contract:
[turnover gate](turnover-gate.md).

**Frozen thresholds.** A **40bp** annual cost ceiling at the frozen 5bp (the monitored
book's own 40.4bp drag, plus a disclosed 10% tolerance) and an **IC margin of 3×** the
breakeven IC; both required. The breakeven definition is delegated to
`signal_decay.breakeven_ic`, so the programme keeps exactly one.

**Calibrated, and the expectation was wrong.** Over **217** frozen replays the implied
mapping tracks measured traded-notional turnover to within 3.5% and is *slightly
conservative* — median measured/implied **0.9854**, range 0.9653–0.9886, conservative in
every replay — because the engine trades only in whole adjusted units and beyond its target
tolerance. The raw implied value is therefore the screening basis: **zero false passes**,
where a median-ratio correction would have admitted one arm the replay rejects.

**Registered candidates.** All three Alpha101 turnover archetypes from the plan's Appendix A
are rejected before any portfolio work: fastest 2,020bp (46× the ceiling), median 600bp
(14×), slowest 200bp (5×) — decided by the cost test alone. The monitored book passes at
40.4bp with a 14.6× IC margin. **A measurement discrepancy reconciled:** P4.13's published
3.97× is the selection-change proxy (19.8bp at 5bp), not the traded-notional drag (8.07×,
40.4bp), so the decay panel's cost headroom is about half what that figure implies. Both
conventions are now named and reported side by side, and the gate reproduces P4.13's proxy
and dispersion exactly (3.9690×, 0.052190).

Consequence: an unconditional daily Alpha101 overlay of the whole book is a measured
impossibility rather than an assumption, so P4.17 must first slow its candidates to a cost
profile inside the ceiling. P4.16–P4.19 must call the gate before producing any portfolio
result. No monitoring, allocation or authority change.

## 2026-10-10 — P4.14 Part B: the ridge rank contributes, but retention still fails

Part B of the FR25 robustness stress, run as its own frozen study in
`var/research/fr25-placebo-20261010-v1/` (protocol `429ec002…`): 200 declared
matched-availability placebo draws, a data-through-2022 ridge refit, and the top-N /
ridge-weight sensitivity surface, all replayed at 5bp with zero delay and fresh cash.
[Findings](fr25-placebo-findings.md) ·
[report](../research/fr25-placebo-2026-10-10/index.html).

**Placebo check passes; retention does not.** FR25's +12.00pp evaluation excess over CP sits
at the **96.50th percentile** of the 200 draws (+6.0008 log against a 4.095pp hurdle), beaten
by **7** random assignments. The typical draw is slightly *negative* (median −0.26pp, 45%
above zero), so the ridge's rank assignment does carry information — any permutation of the
M1 ordering does **not** do as well. But the frozen 6-month interval still fails at
[−0.12%, +2.51%], Part B may not rescue a failed interval test, and the verdict is
**inconclusive** with retention **not preserved**, identically under both readings of the
plan's verdict sentence. The positive tail of the placebo distribution comes from churn, not
information: the seven winning draws differ from CP on ~23 of 70 decisions against FR25's 13.

**The frozen-through-2022 fit retains about 60% of the recent expanding-fit edge.** A ridge fitted only on the 83
labels completed by 2022-12-31 and replayed from 2023-01-03 keeps **+4.20pp of FR25's
+7.06pp** excess over CP, with a lower maximum drawdown (−8.31% vs −8.66%) and a better
Calmar. Refitting on the parent's frozen training rows reproduces the published forecasts
exactly, so this is a re-fit, not an approximation.

**The sensitivity surface has no stable winner.** Top-N 4/5/6/7 × ridge weight 10/25/40%:
the frozen Top-6 · 25% cell is not the best; the high-excess Top-4 corner carries −10.6% to
−12.4% drawdowns and a Calmar below CP's at 40%; and the surface is non-monotone in ridge
weight (2 / 13 / 31 changed decisions at six slots), which is path luck rather than a
dose-response relationship.

Consequence: FR25 stays a monitored research lead. The mechanism now has a positive answer
to "does the ridge contribute at all?" and a negative answer to "is the advantage
distinguishable from noise at the frozen tolerance?", and the second governs retention. No
re-tuning, no monitoring, allocation or cap change.

## 2026-10-10 — P4.14 Part A: FR25's edge is real but concentrated and not significant

Robustness attribution of FR25 versus CP over the 2021+ evaluation window
(+12.00pp, +0.0600 log), against a retention tolerance frozen before the
statistics were computed. Full detail: [FR25 robustness findings](fr25-robustness-findings.md).

**Verdict: inconclusive.** Three of four frozen checks resolved: complete-year
positivity passes (4 of 5, 80%), leave-one-selection-out passes, and the
**6-month bootstrap interval fails** at [−0.12%, +2.51%]. The placebo test belongs
to Part B and has not run, so the result can never be reported as preserved.

**The mechanism does what it claims.** Tiling the window at the 13 changed
selections shows they account for **96%** of the difference — the advantage is
attributable to the substitutions the recipe makes, not to something else in the
sample.

**But it is concentrated.** The two 2026 substitutions are 58% of the changed
total; the largest single tile is 31.3%; the top three are 79.3%. The 2024-10-01
substitution into EWH/GLD/LQD and out of HYG is the biggest tile in absolute terms
and it **lost** 1.50 log points. Outside 2021 and the partial 2026, FR25 and CP are
effectively the same portfolio: 2022 is a rounding error and 2023 is negative.

Consequence for the plan: FR25 stays a monitored research lead. It is not
promotion evidence, and this does not by itself deallocate — that remains an
operator decision. Part B (placebo rank, data-through-2022 refit, top-N and
financial-weight sensitivity) is the outstanding work and needs its own frozen
study, because each perturbation changes the selected assets and therefore the
realised path.

## 2026-10-10 — P4.13 signal decay measured; no decay in the funded selection score

First item of the [signal decay and alpha plan](signal-decay-and-alpha-plan.md)
completed, including the dashboard panel and the allocation-aware warning.
Full method, numbers and limitations: [signal decay findings](signal-decay-findings.md).

130 monthly decisions, 2016-01-04 to 2026-10-01, 14 candidates, batch
`b02d9372…`. **Measured** annual one-way turnover 3.97x; 21-session return
dispersion 5.22%; cost gate at 5bp.

| Signal | Long-run IC | Recent IC | IR | Status |
| --- | ---: | ---: | ---: | --- |
| `m1_total` (selection score) | 0.0548 | **0.0943** | 0.13 | healthy |
| `m1_volume` (quarter of the score) | 0.0141 | −0.0110 | 0.04 | **decayed** |
| `momentum_63` | 0.0696 | 0.1245 | 0.16 | healthy |
| `drawdown_252` | −0.0085 | −0.1639 | −0.02 | **decayed** |

**No decay is visible in the funded strategy's selection score**, and its recent
IC is above its long-run mean. However the 95% block-bootstrap interval for
`m1_total` spans zero at every block length ([−0.016, +0.127] at 3 months), so
this sample cannot establish that the ranking edge is nonzero. The breakeven IC at
the measured turnover is 0.0032, about 17x below the observed IC: the current
signal is not cost-constrained on this pool.

Two things follow. First, the FR25 concentration concern is not a *decay* problem
in the M1 component, so P4.14's robustness stress remains the right next test.
Second, the same gate applied to Alpha101's own turnover gives a breakeven IC of
0.100 at the median — above every signal measured here — so P4.15's turnover gate,
not the signal construction, is the binding constraint on P4.17.

**Coverage gap, published not hidden:** the financial ridge, context ridge,
rolling XGBoost and USD ridge forecasts are not yet measured; their per-decision
values are not published. The FR25 and CR warnings therefore rest on the M1
component only until that is closed.

## Next research phase — registered 2026-10-10

The next phase is the [signal decay and alpha plan](signal-decay-and-alpha-plan.md),
registered as `P4.13`–`P4.21`. It starts with **signal decay and IC
instrumentation** and an **FR25 robustness stress**, neither of which needs new
data, before any Alpha101 work.

Two conclusions from reviewing the Alpha101 paper are frozen into that plan.
First, of the 101 formulaic alphas, 49 cannot be computed with the data we hold
(43 need `vwap`, 18 an industry classification, one market capitalisation), 83
contain a cross-sectional operator, and only **16 are both implementable and free
of a cross-sectional operator**. Second, the paper's own Table 1 puts the median
alpha at a 2.10-session holding period and ~120× annual one-way turnover —
roughly **6.0% a year at our frozen 5bp**, against the current strategy's ~8× and
~0.4% — and its published figures exclude transaction costs. Alpha101 is
therefore usable only as a restricted feature set at the selection layer, behind
measured turnover and decay, never as an unconditional daily overlay.

Intraday signal activation and stop-loss execution is registered as a platform
workstream (`P5.11`), not research. There is no published intraday data and no
intraday execution stack.

Work proceeds **one item at a time, with a review and reflection between items**.

## Standing research scope — updated 2026-10-10

At the user's direction, future ETF, feature and momentum research uses the full
candidate pool. Do not repeat XLE/XLB-only model tests or make those two ETFs'
forecast errors the basis for judging full-pool signals. Whole-portfolio asset
attribution remains useful; preserve historical subgroup evidence without
extending that standalone test program. Assets compete in the candidate pool;
none is forced into the portfolio. A failed portfolio-recipe screen is distinct
from rejecting the underlying predictive signal.

## 2026-10-10 — FR25 authorized for application-owned monitoring

The user authorized monitoring the frozen FR25 selector as
`research_fr25_14_v1`. The application now fits the financial ridge monthly,
blends 75% M1 rank with 25% financial total-return rank before the positive
126-session gate and top-six selection, and publishes scheduled and indicative
targets, fills, daily NAV, held weights, the matched benchmark and the full
shared report with an inspectable rank table.

Research parity was verified against the frozen selection-blend protocol
`5399931f5267d8beceb1ff52b15d84a81547f4f1e8a285a413bace7702769276`: 130
decisions, 898 fills, 2,707 daily NAV observations, 130 model fits and matching
final positions. Membership generation 4, membership revision 4. Evidence:
`var/research/fr25-monitoring-20261010/`.

That parity is bound to audited price batch `4bfdef17…`; the live runtime revision
calculates on the newer committed batch `b02d9372…`, so the two are distinct
evidence versions of the same frozen recipe rather than bit-identical outputs.
Parity claims must name their batch.

This authorization does not upgrade the evidence. FR25 remains an
already-inspected retrospective candidate that passed practical effect-size,
mean-only, cost/delay and risk-budget screens but **no** 5% Holm contrast across
the 50-comparison family, with recent substitutions concentrating its advantage.
Monitoring is not promotion: allocation readiness stays false, the 14-ETF
execution gate stays closed, and no capital, approval, reconciliation or broker
authority changes. The contract is in
[FR25 tracked strategy](../docs/fr25-selection-tracking.md).

## 2026-10-10 — Predictive ranks moved into full-pool selection

Executed the user's requested momentum/XGBoost/ridge selection comparison.
The fixed full14 candidate pool ranks the existing M1 score (75% momentum,
25% volume), causal XGBoost forecasts and context/financial ridge total-return
forecasts on the same midrank scale. Ten predeclared blends: two M/X blends,
four M/R or M/X/R blends for each ridge group. Positive126 eligibility,
top6/min4, defensive fallback, inverse-volatility sizing and downstream controls
remain fixed. Primary arms keep the existing XGBoost sizing tilt and add no
economic sizing overlay. Final45 cap is controlled separately against exact
M1. Eight same-availability training-mean controls, three XGBoost-placement
controls, two matched-target-gross controls and seven references complete the
30-arm experiment. Required-ridge gaps revert the whole selector to M1;
missing XGBoost fails closed. No model or parameter refits after registration.

| Fresh-cash 2021–2026-10-08, 5bp | CAGR | Sharpe | Calmar | Max drawdown |
| --- | ---: | ---: | ---: | ---: |
| CP: capped M1 control | 11.92% | 1.106 | 1.435 | -8.31% |
| Context ridge sizing only | 12.09% | 1.122 | 1.436 | -8.42% |
| Financial ridge sizing only | 12.03% | 1.108 | 1.425 | -8.44% |
| CR50: 50% M1 / 50% context rank | 12.49% | 1.171 | 1.533 | -8.14% |
| FR25: 75% M1 / 25% financial rank | 13.09% | 1.193 | 1.512 | -8.66% |
| X25: 75% M1 / 25% XGBoost rank | 12.56% | 1.159 | 1.448 | -8.67% |
| CEQ: equal M1/XGBoost/context | 11.10% | 1.058 | 1.288 | -8.62% |
| FEQ: equal M1/XGBoost/financial | 12.95% | 1.192 | 1.427 | -9.07% |

CR50 and FR25 pass the frozen +0.05 Sharpe/+0.05 Calmar effect-size screen,
the CAGR/drawdown budgets, matched mean-only checks and positive cost/delay
comparisons. CR50 improves Sharpe/Calmar +0.065/+0.099; FR25 +0.087/+0.078.
This is a materially larger portfolio effect than the corresponding sizing
overlays. Neither leading selection blend uses XGBoost in its selector; both
retain XGBoost downstream. Increasing XGBoost's selection share to50% weakens
Sharpe to1.003. Equal blending is not generally superior. Removing the existing
XGBoost sizing tilt does not improve either equal blend.

FR25 is the stronger long-history lead: 2016+ CAGR/Sharpe rise from CP's
10.65%/1.062 to11.21%/1.109; max drawdown worsens -19.49%→-19.83%.
CR50's full-history CAGR/Sharpe are10.55%/1.061, with -20.95% drawdown.
FEQ's full-history drawdown reaches -30.46%, despite strong2021+ return.
Retain CR50 as a secondary evaluation-period lead, not a stable full-history
improvement. All results remain retrospective and the weights were chosen
from a predeclared finite menu, not an independent holdout.

FR25 changes13/70 selections, one replacement each; eight entering ETFs beat
the displaced name in the subsequent rebalance-open interval, with mean
entrant advantage2.60pp. Mean target gross changes only+0.040pp; annual traded
notional drops8.59×→8.07×. July2026 TLT→XLE and August2026 HYG→EWY correspond
to+1.974pp/+1.670pp actual calendar net outperformance. October2024 HYG→TLT
loses-1.157pp. FR25's2026 net annual-return advantage is+4.552pp, making recent
decision concentration a material limitation. CR50 changes35/70 selections,
with17 positive equal-weight entrant/exit outcomes; portfolio sizing and
timing still matter. Its+5.012pp2021 gain contrasts with-1.709pp2022 and
-1.402pp2023. These are attribution examples within the full pool.

No registered contrast passes5% Holm across the50-comparison return family at
3/6/12-month blocks. FR25's six-month Sharpe-difference interval is
[-0.026,+0.226], CR50's[-0.070,+0.246]. No statistically robust superiority
claim or promotion follows from the practical screen. Equal-blend target-gross
controls match CP on all70 evaluation decisions but do not establish matched
volatility/factor risk. No new universe/threshold/weight search was added after
seeing these results.

Disposition: freeze FR25 as the primary selection-research candidate and CR50
as secondary for prospective and concentration robustness evidence. Do not
retune the inspected sample. Monitoring and funded allocation were not changed;
any future monitored version must be a complete app-owned strategy. New sector
release-history qualification remains separately queued; standalone SPY stays
deferred. [Complete results and interactive rank tables](../research/selection-blend-2026-10-10/index.html).
Evidence: `var/research/selection-blend-20261010-v1/`; protocol SHA-256
`5399931f5267d8beceb1ff52b15d84a81547f4f1e8a285a413bace7702769276`.

Validation: 240 economic replays, 30 native engine checks, 54 exact control
reproductions, 72 inference jobs and 18 focused tests pass. Independent exact
rational ranks verify 40,040 cells and 2,990 selection/gate/cap/label contracts.
Poisoning current/future prices and future models does not change prior-close
decisions. All 30 shared reports, local links, source hashes and JavaScript
syntax pass; a local DOM harness exercises 1,540 rank-table states. Browser
automation blocks local file URLs, so no browser-interaction pass is claimed.
Static charts were visually inspected. Acceptance is in `acceptance.json`.

## 2026-10-10 — Full-pool IC diagnosis: retain signal leads, distinguish recipe failure

The user's IC challenge prompted a frozen diagnostic follow-up, using all 14
candidates and the exact prior models/decisions/net ledgers. No refitting,
parameter search, new strategy arm or market-data ingestion was performed.
The earlier XLE/XLB-only MAE discussion does not decide the full-pool question.
The original recipe-retention failure remains valid, but rejecting economic
information itself would overstate that evidence.

| Ridge model | Full-pool total IC | Training-mean IC | Macro-increment IC | Partial rank IC* |
| --- | ---: | ---: | ---: | ---: |
| Context | 0.1182 | 0.0435 | 0.0887 | 0.0836 |
| Financial | 0.1188 | 0.0706 | 0.1213 | 0.0985 |
| Combined | 0.1152 | 0.0435 | 0.1003 | 0.0960 |

*Descriptive correlation after controlling ranks for training means and M1
selection scores. Context/combined have 58 complete labels; financial has 69.
All three total-IC marginal intervals are positive with 3/6/12-month calendar
blocks. Financial/combined increment intervals are also individually positive.
Paired improvement over the mean baseline remains uncertain; none of the 12
incremental-IC tests passes 5% Holm. This is suggestive ranking evidence,
not established incremental alpha or independent prospective validation.

The implementation preserves the existing selected members and cash budget;
it thresholds macro increments into 0.9/1.0/1.1 multipliers rather than using
total forecast ranks. Context changes 40/70 decisions: 12 unavailable, six
all-cash, two single-holding and ten uniform-multiplier months cannot change
weights. Mean capital shifted is 1.74% overall, 3.04% when changed. On identical
months with at least three positive targets, financial total IC declines from
0.130 across all 14 to 0.049 within held assets; context declines 0.138→0.108.
This is a selection diagnostic of the full pool, not a separate universe test.

Context contributes +0.167pp CAGR, +0.0162 Sharpe and +0.0010 Calmar versus CP.
Its Sharpe gain decomposes into +0.0137 from arithmetic mean return and +0.0025
from lower volatility. Its Calmar gain from higher CAGR (+0.0202) is nearly
cancelled by a worse maximum drawdown (-0.0192). Annual cost changes are near
zero or favorable, so costs are not the primary obstacle. Financial's higher
volatility offsets most of its mean-return Sharpe benefit.

Context adds +0.625pp net calendar return in 2024, but -0.022pp in 2023.
Financial adds +0.943pp in 2022 and subtracts -0.644pp in 2025. Context's April
2022 SPY underweight contributes positively; its April 2025 energy overweight
and gold underweight contribute negatively. During the common March 19–April 8,
2025 drawdown, all asset contributions reconcile to -11.1bp relative return:
XLE -23.9bp, partly offset by MCHI +12.0bp, GLD +3.1bp and other holdings.
Context's worst drawdown is -8.419% versus CP -8.308%, with recovery June 24
versus June 12. Predeclared trailing-trend/stress splits disagree across models
and are descriptive; do not turn them into tuned trading gates.

Disposition: retain context and financial ridge as signal-research leads;
combined has no demonstrated advantage over context, and trees have weaker
full-pool IC. The existing sizing recipes still fail their frozen screen.
Monitored M1/14/CR12 and funded F3 remain unchanged. Next proposed full-pool
experiment: freeze a finite comparison of rank-based selection/sizing versus
the current threshold overlay, including a historical-mean-only control,
matched risk/cash budgets, unchanged admission rules and prospective evidence.
Specify the experiment before running it; do not force assets or conduct an
open-ended search. Original-release sector-history qualification remains a
separate queued prerequisite for new data blocks; standalone SPY stays deferred.

[Diagnostic report](../research/full-pool-signal-diagnostics-2026-10-10/index.html).
Evidence: `var/research/full-pool-signal-diagnostics-20261010-v1/`.
Protocol SHA-256 `5f5467917cfe5bb4d46debd02bd1a2ddc73383e61244bf789073920392cf0f4a`.
Verified 10,677 parent-manifest entries, seven replay bundles, exact NAV/cash,
monthly asset attribution and peak/trough contribution reconciliation. Twelve
focused tests pass; no service, strategy or execution behavior changed.

## 2026-10-10 — Expanded-universe economic revisit completed

Executed the queued economic revisit once XLE/XLB and M1/14 were qualified.
The fixed M1 top-six candidate selector is unchanged. Seven overlay arms use
existing context (13), financial (8) and combined (21) features, per-ETF ridge
alpha 1 and depth-two/minimum-12-leaf trees. No feature, threshold or momentum
search was added. CP separately clips M1 targets above 45% and leaves the excess
in cash; all economic arms preserve CP's exact positive membership and cash.
The cap changes four of 130 monthly decisions, adding 0.183% average target cash.
No added ETF is forced into a portfolio.

| 2021-01-04–2026-10-08 | CAGR | Sharpe | Calmar | Max drawdown |
| --- | ---: | ---: | ---: | ---: |
| Unchanged M1/14 | 11.91% | 1.104 | 1.433 | -8.31% |
| CP: explicit cap-only control | 11.92% | 1.106 | 1.435 | -8.31% |
| Context ridge (CR) | 12.09% | 1.122 | 1.436 | -8.42% |
| Context tree (CT) | 11.94% | 1.109 | 1.406 | -8.49% |
| Financial ridge (FR) | 12.03% | 1.108 | 1.425 | -8.44% |
| Financial tree (FT) | 12.00% | 1.107 | 1.401 | -8.56% |
| Combined ridge (AR) | 12.04% | 1.115 | 1.443 | -8.34% |
| Combined tree (AT) | 11.83% | 1.094 | 1.331 | -8.88% |

USD, 5bp per traded dollar, zero-interest cash, fresh-cash evaluation. MR's
matched-context models/economics reproduce CR exactly; financial availability
does not remove further context-ready rows in this sample. The common October
8 cutoff is deliberately pinned to the preceding M1 study; later app prices
are not injected into this comparison. All history was previously inspected,
and M1 itself was selected retrospectively.

CR's matched-control gain is +0.167 percentage points CAGR, +0.0162 Sharpe and
about +0.0010 Calmar, below the registered +0.05 Sharpe/+0.05 Calmar threshold.
Its positive cost/delay comparisons do not override that shortfall. The
six-month-block 95% Sharpe-difference interval is [-0.0086,+0.0418]. The
twelve-month marginal Sharpe interval is positive, but Calmar and jointly
adjusted mean returns do not establish robust superiority. None of the 18
mean-return contrasts passes 5% Holm at 3/6/12-month blocks. Trees do not beat
their paired ridge controls; combined models do not beat matched context on
both risk ratios. No candidate passes the predeclared retention screen.

Prediction evidence also remains weak. XLE/XLB next-month return MAE is 5.79%
for context ridge versus 5.01% for the ETF-specific training mean, 5.39% versus
5.02% for financial ridge, and 6.53% versus 5.01% for combined ridge. These
paired samples differ by availability and are not interchangeable. Context and
combined models are ready on 58/70 evaluation decisions; financial models on
70/70. November 2025–October 2026 context abstentions remain intact, including
incomplete CPI windows. The latest capture never repairs an earlier gap.
Context ridge changes 40/70 allocations; XLE rises/falls in 6/10 months and XLB
in 3/17. Response signs are learned per ETF, not assumed from economic growth.

Full-history CR CAGR/Sharpe/DD are 10.73%/1.070/-19.59%, versus M1's
10.64%/1.061/-19.48%. FR weakens to 10.59%/1.051/-20.36%. Preserve these small
and inconsistent effects rather than retuning the same sample. Disposition:
reject these recipes for additional monitoring/promotion under the frozen
screen; keep monitored M1/14 and CR12 unchanged, and F3 funded. Next qualify
original-release sector/energy history before introducing new feature blocks.

Evidence: [13 complete shared reports and diagnostics](../research/expanded-economics-2026-10-10/index.html),
`var/research/expanded-economics-20261010-v1/`. Protocol SHA-256:
`9265c4e96c0a48bc17815b422eeab40f8de29e21a3c45b33e0ffb4950916100a`.
Audited price batch `4bfdef171ba1d180f2191c589d269a9ad42e2f497b9f069b80e1e9043668f3fd`;
economic batch `9fb6784447635430354fa0547e8787f37d0e7c69d60a62053a65b0279ff8b8b4`.
All 104 replays, 13 native checks, 57 inference jobs (10,000 draws each), 57
focused tests and 910 selection/cash/cap/label checks pass. All 130 feature
states reproduce from the original published snapshots; five portfolio controls
reproduce exactly. There are 520 model evaluations, of which 336 have sufficient
data to fit. Input/output/report hashes, links, JavaScript and plot checks pass.
Control revision 5, membership and all 270 order records are unchanged. The
independent app has advanced through October 9 with empty analytics errors.

## 2026-10-10 — Deferred standalone SPY idea

User requested continuing the next item and deferred SPY dip-buying for a later
standalone strategy study. Preserve it separately from the completed bounded
F3 cash-sleeve experiment; the latter is not a test of an independent SPY
strategy. No additional SPY threshold search or monitoring is authorized now.

The economic-model revisit after universe expansion is now completed above.
Historical EIA/CFTC/issuer feature qualification remains the next separate
data-dependent work item; its missing availability evidence is not bypassed.

## 2026-10-09 — P4.11 cash reserve and loser-basket study completed

Tested the user-authorized separate stress sleeve, including assets rejected
by F3's positive-momentum gate. Parent F3 and its original 12-ETF pool remain
exactly frozen. SPY, bottom three and top three use identical cash limits and
stress/confirmation rules; baskets freeze at first deployment. Bottom/top
ranking uses the existing pure 63/126/252-session momentum blend, without
volume or a positive gate. These are mixed-asset ETFs, not stock-level losers.

Monthly SPY drawdowns of 10/20/30% trigger equal tranches from one locked
dollar budget. Confirmation requires SMA63 and positive 21-session return.
Exit occurs at 95% of the entry peak or after twelve monthly intervals;
spent tranches cannot re-arm. Stage A uses existing F3 cash, capped at 20%
NAV. Separate Stage B cases scale F3 to 90%/80% and reserve 10%/20%. Both
ZERO cash and audited BIL parking are tested, with BIL capped at 45% and a
2% operational cash floor. No final cap is silently imposed on inherited F3.

| ZERO cash, 2021-01-04–2026-10-08 | CAGR | Sharpe | Max drawdown |
| --- | ---: | ---: | ---: |
| Exact F3 | 10.58% | 1.062 | -11.69% |
| Existing cash, scheduled SPY | 10.79% | 1.068 | -10.75% |
| Existing cash, stress SPY | 10.76% | 1.072 | -10.84% |
| Existing cash, confirmed SPY | 10.65% | 1.064 | -11.36% |
| Existing cash, stress bottom three | 10.52% | 1.053 | -11.98% |
| Existing cash, stress top three | 10.58% | 1.059 | -11.70% |
| 10% fixed reserve / stress reserve | 9.51% / 9.60% | 1.060 / 1.067 | -10.57% / -10.14% |
| 20% fixed reserve / stress reserve | 8.45% / 8.63% | 1.059 / 1.070 | -9.44% / -8.57% |

USD, 5bp per traded dollar, fresh-cash evaluation; retrospective previously
inspected history. Fixed reserves cost 1.07/2.14pp CAGR; stress deployment
recovers only 0.09/0.18pp. BIL lowers the 10%/20% fixed-reserve drag to
0.79/1.58pp versus the same-parking parent, still outside the registered
0.5pp return-sacrifice budget for protection. Existing-cash SPY does not beat
scheduled deployment, so its modest parent improvement is not timing evidence.
Full-history Stage A drawdown stays near -16.42%; stress SPY CAGR is 10.01%
versus F3's 9.85%. Bottom-three full CAGR is 9.89%, weaker in evaluation.

Only three monthly market-stress episodes occur: January 2019, March 2020
and May 2022. Existing F3 cash funds two, and only the 2022 episode falls in
evaluation. It funds no 2020 sleeve because the parent had already invested.
In the 2022 full-history cycle, bottom-three MCHI/TLT/EWJ loses about $5,175
on a $323,152 locked budget, after falling as much as 13.57% of that budget;
SPY earns about $15,205 after a 5.91% budget loss. Budget denominators include
unused cash; these are sleeve P&L diagnostics, not asset-return drawdowns.

Disposition: reject the tested extra-reserve and loser-basket recipes for
progression under the frozen thresholds. Existing-cash SPY remains a small,
inconclusive effect below the worthwhile-improvement threshold. No comparison
passes either effect-size/protection screen or 5% Holm across the 46 contrasts
at 3/6/12-month blocks. This does not establish that reversal never works.
Do not optimize thresholds from these few episodes or promote a cash variant.
Retain M1/14 only under the separate monitoring authorization below. Next
research returns to unresolved data qualification and the already queued
information-signal work; combining failed cash recipes is not the next step.

Evidence: [complete study and 30 shared reports](../research/cash-stress-losers-2026-10-09/index.html),
`var/research/cash-stress-losers-20261009-v1/`. All 232 dynamic/frozen replays,
30 independent native checks and 141 inference jobs pass; 10,000 draws per
job. Exact F3 reproduction, paired phase-dollar reconciliation, lower-frequency
episode sensitivity, costs/delay, cash-proxy Sharpe and risk-matched URTH are
included. Protocol SHA-256:
`cc19d9f608c8484aedbf81afae41d3db9e696daed1f7f0b8be07d86760e10b4a`.
Audited price histories are reconstructed vintages, not proof of historical
publication availability. BIL is not broker interest; no uncertified FX is
used. Settlement timing/product permissions remain unqualified live inputs.

## 2026-10-09 — M1/14 added to app-owned monitoring

User authorized monitoring `research_m1_14_v1`: XLE/XLB join the original 12
candidates, with 21/63/126-session momentum and a positive 126-session gate.
Top six, minimum four and the F3 defensive-cash fallback remain unchanged.
No asset is mandatory. Audited raw dollar activity uses adjusted direction;
rolling XGBoost and USD models refit for this distinct pool.

The app's own service now publishes monthly rebalances, daily NAV/held weights,
October 9 indicative targets and the complete shared report/decision chart.
All 130 decisions, 907 fills and 2,707 daily values exactly reproduce the
registered research result. Nine native app checks pass, including the new
M1/14 and 14-ETF inverse-volatility benchmark. Existing USD economics remain
unchanged; all currently monitored entries are Current through October 8.
Monitoring is not promotion: M1/14 is ineligible for capital allocation until
its separate 14-ETF execution contract and promotion evidence are approved.
F3 remains funded at control revision 5; all 270 order records are unchanged.

Acceptance: `var/research/m114-monitoring-20261009/runtime-final.json`;
calculation revision `baad7794e23ccaeee3d359fd6c6ee0565d6873cfd60c67e9cc31ffb5e9e991c6`.
The historical candidate report below remains the selection evidence; its
earlier no-monitoring disposition is superseded only by this explicit user
authorization, not by a new claim of statistical superiority.

## 2026-10-09 — Corrected candidate-pool and momentum experiment completed

The user meant candidate-pool expansion throughout. The previous all-asset
inverse-volatility experiment answers a different question and cannot reject
adding XLE/XLB to the top-six selector. The corrected study adds no mandatory
allocation: four predeclared momentum policies × original 12 / expanded 14
candidates, retaining the six-slot limit and F3 defensive-cash fallback.

M0 is the existing 63/126/252-session ranking and positive 252-session gate.
M1 uses 21/63/126 and a positive 126-session gate. M2 excludes the most recent
21 sessions; M3 divides momentum by 63-session volatility. Ranking blend,
volume weight and other overlay parameters stay fixed. Shared XGBoost and USD
models refit causally for each pool, with one model schedule per pool reused
by all four policies. Audited raw dollar activity is used consistently in all
eight new arms; frozen legacy F3 is reproduced separately. That basis/refit
bridge moves full-history CAGR from 9.8458% to 9.8306%, not a pool effect.

| Rule / pool | 2016–2026 CAGR | Sharpe | Max drawdown | 2021+ CAGR | Sharpe | Max drawdown |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| M0 / 12 | 9.83% | 1.047 | -16.42% | 10.52% | 1.054 | -11.63% |
| M0 / 14 | 9.56% | 0.924 | -16.33% | 10.14% | 0.897 | -12.89% |
| M1 / 12 | 9.56% | 1.072 | -18.79% | 9.34% | 1.033 | -8.02% |
| M1 / 14 | 10.64% | 1.061 | -19.48% | 11.91% | 1.104 | -8.31% |
| M2 / 14 | 8.99% | 0.863 | -21.10% | 10.70% | 0.953 | -10.79% |
| M3 / 14 | 8.40% | 0.980 | -14.33% | 8.49% | 0.943 | -9.72% |

USD, 5bp per traded dollar, zero-interest cash, through October 8. The 2021+
period restarts from cash and is the registered chronological evaluation;
all history was previously inspected, so this is not an untouched holdout.
M0 selects XLE in 48/130 months (36.9%) and XLB in 59/130 (45.4%). Their
average held weights are 4.44% and 6.62%. M1 selects them in 48 and 63 months.
New candidates therefore enter often enough to matter, and can also change
cross-sectional ranks and model labels when not selected.

Disposition: unchanged-momentum expansion does not improve the observed
risk-adjusted results. M1/14 is a useful research lead, with a cost/delay-stable
2021+ advantage over M0/14, but deeper full-history drawdown and no convincing
paired evidence. Six-month block 95% interval for its Sharpe improvement over
M0/14 is [-0.083, +0.526]; all 11 mean-return contrasts fail 5% Holm across
3/6/12-month blocks. Its expansion benefit versus M1/12 also fails the combined
cost/delay Sharpe-and-Calmar check. No variant establishes a robust replacement;
no monitoring, promotion, strategy allocation or execution change.

Validation: 260 causal XGBoost fits, 94 accounting replays, 12 frozen-target
native LEAN parity checks, 36 uncertainty jobs (10,000 draws each), exact legacy
F3 fills/NAV/targets/positions reproduction, 65 focused tests, Ruff and input /
model / decision / output hashes. Control revision 5 and 270 order records
unchanged; analytics errors empty. Report assembly initially withheld publication
while native checks were pending, then finalized after all 12 passed.

[Complete comparison, selection frequencies, uncertainty and 12 full reports](../research/candidate-pool-momentum-2026-10-09/index.html).
Frozen evidence: `var/research/candidate-pool-momentum-20261009-v1/`.
Protocol SHA-256: `8242daf88c16cf28c8f12f16f68aafd84ff4ec71dfbc85d37cc0aa32acdfce60`.

Specification correction: current `research_fallback_f3_v1` does **not** include
a final 45% cap; that cap exists in some economic-study controls. F3 has the
incoming inverse-volatility cap and later active-weight constraints, but selection
and downstream overlays can produce final weights above 45%. This study preserves
the exact rule and reports concentration. P4.11 remains next on the original pool;
freeze exact current F3 as R0 and label any added cap as a separate intervention.

## 2026-10-09 — XLE/XLB admitted; first universe control rejected

Published common-cutoff XLE/XLB histories through October 8, 6,991 sessions each,
with issuer identity/listing validation and full hash readback. XOP is quarantined:
issuer listing June 23, 2006 conflicts with provider metadata/first bar June 22.
An explicit hold preserves the failed evidence without blocking other funds.
Read-only IB ISIN discovery verifies BIL/XLE/XOP/XLB identities; account/product
permission and settlement eligibility remain unverified. Holdings residuals and
split-aware issuance remain unresolved. [Admission evidence and study](issuer-etf-recorder.md#price-admission-and-first-universe-control--completed-2026-10-09).

Frozen 12-versus-14 ETF inverse-volatility control: adding XLE/XLB changes CAGR
5.73%→6.16%, Sharpe 0.748→0.753, Calmar 0.255→0.311 and maximum drawdown
-22.46%→-19.81% over 2016-01-04–2026-10-08 (USD, 5bp costs, zero cash interest).
The predeclared +0.05 Sharpe threshold fails; all paired block intervals include
zero. Cost/delay consistency passes, but does not override the failed screen.
Reject unchanged-sizing expansion; no claim about expanded F3/ranking follows.
Current F3 is a matched benchmark, exactly reproducing app economics.
All 14 replays, four native checks and three 10,000-draw uncertainty jobs passed.
Full shared reports include held/target weights, NAV, benchmarks and decision flow:
[research results](../research/energy-materials-universe-2026-10-09/index.html).

This previously inspected history and present-day ETF selection are retrospective,
not an untouched holdout. New arms use audited adjusted prices only; F3 retains
its disclosed inherited volume proxy. No new issuer/EIA/CFTC data is backdated,
and uncertified historical FX is excluded. Next: P4.11 on the retained current F3
and original universe, freezing cash economics and full-cycle deployment rules
before outcomes. Monitored definitions, capital and execution authority stay fixed.

Final runtime acceptance: all eight app native replays pass; five monitored
strategies are current through October 8 on revision
`1ef8c43dd057b1a0ed3c38dd2b331528da54be174e9985860cbd5a704cf4617d`.
Analytics is error-free with no freshness/startup flags; allocation calculation
status is OK, control revision 5 and 270 order records are unchanged. The separate
IB market-data recorder reports competing-session error 10197; no login/session
was changed to suppress it. Email delivery remains unconfigured.

## 2026-10-09 — Cash reserve and stress-deployment study queued

The user requested research on whether buying during market stress compensates
for cash drag and falling-knife risk. Execution item **P4.11** is Pending in the
[ETF roadmap](etf-research-expansion-roadmap.md#cash-reserve-and-stress-deployment--queued-2026-10-09),
after the current ETF admission and frozen universe-control milestone. First test
redeployment of existing capped-F3 defensive cash against unchanged and scheduled
re-entry controls; then compare 10%/20% additional reserves with ordinary
rebalancing, staged stress buying and recovery-confirmed deployment.

Freeze complete rules and acceptance tolerances before outcomes. Required evidence
covers full-cycle waiting/deployment/replenishment economics, matched exposure,
cash yield/FX qualification, crisis dependence, costs/delays, audited pinned inputs,
shared app calculations and native parity. Return enhancement and protection with
a return sacrifice are separate conclusions. This is queued research, not a new
backtest result, monitored definition, promotion or allocation change. Existing
issuer/ETF work continues and economic ridge retains its current freeze.

## 2026-10-09 — Prospective issuer ETF fundamentals recorded

The next recorder-first milestone is implemented for XLE, XOP and XLB. The app
captures issuer holdings, NAV/shares/AUM, valuation/growth statistics and industry
allocation every six hours, with independent fund publications and Market Data
→ ETF Fundamentals inspection. Eight statistics per ETF retain separate section
dates and actual capture times. First captures occurred October 8 at
16:21:59–16:22:06 UTC (October 9 local); October 7 issuer dates never grant earlier
availability. Hash-verified readers enforce strict cutoffs and feature-group
freshness/missing-data checks. See the [recorder and admission evidence](issuer-etf-recorder.md).

NAV/share/AUM reconciliation passes. All three holdings files have small
unexplained residuals to 100%, exceeding displayed-precision rounding. Preserve
their exact signed weights and missing sectors; show yellow warnings and reject
holdings-based features until reconciled. Shares are recorded, not labeled flows.
The issuer aggregates are not original historical analyst forecast vintages.

The current price catalog already contains XLE/XLB through September 25 with
explicit identity/availability/raw-basis limitations; XOP is absent. Next: common
cutoff price publication, issuer/security identity reconciliation, read-only IB
contract qualification, then a frozen expanded-universe control. No new backtest,
allocation or monitored-strategy change was made at this milestone.

Validation: 83 distinct focused tests pass; one opt-in disposable ClickHouse test
is skipped. Ruff, diff checks and browser selection/holdings inspection pass,
with no browser warnings/errors. Live publications, strict cutoff rejection,
feature-group isolation and preserved pins across application refresh were
verified. The guarded restart leaves analytics error-free and strategies current
through the latest completed US session, October 7.

## 2026-10-08 — EIA energy context recorded and published

The app now captures free official petroleum and natural-gas releases hourly
and exposes them in Market Data → Energy Data. The first publication contains
12 petroleum indicators (inventories, supply, demand and refinery activity) and
five Lower 48 gas-storage indicators, including separate net change and implied
flow. Both cover October 2. Petroleum was released October 7 at 14:30 UTC and
captured October 8 at 15:44:22 UTC; gas was released October 8 at 14:30 UTC and
captured at 15:44:30 UTC. Original raw bytes, revision flags, config/code hashes
and independently verified publication pins are retained.

The petroleum release's 314-row crude history is one current snapshot. It is
available only from capture, not from each observation date. The inspected
historical archive page had inconsistent date metadata, so original-release
archive admission remains unresolved. These inputs are physical context, not
proven leading signals or consensus surprises. Pinned readers enforce actual
first-seen cutoffs, freshness and missing-value checks. No historical return
experiment or Sharpe/Calmar claim has been made with this data.

The [recorder contract and next research stage](energy-fundamentals-recorder.md)
contains source qualification, exact publication pins and the proposed finite
per-ETF linear/tree comparison. Next: prospective issuer holdings/shares/NAV,
ETF identity/price admission, then a frozen expanded-universe control. Economic
ridge stays frozen until that universe revisit; single-stock trading is excluded.

Validation: 65 distinct focused recorder, publication, recovery and navigation
tests pass; Ruff and browser checks pass. Application-owned publications are
visible and source checks have no recorded error. No strategy allocation or
execution authority changed.

## 2026-10-08 — CFTC positioning recorder published; no historical backtest

Market Data → Fund Positioning now includes an app-owned, raw-first recorder for
the CFTC disaggregated futures-only reports. Six contracts cover WTI and natural
gas positioning plus COMEX gold/silver/copper and LME aluminum. The normalized
features report managed-money, producer/merchant and swap-dealer net-to-open-
interest ratios; original rows and publication hashes are retained. The audited
batch contains 1,903 reports beginning 2020-01-07 through September 29, 2026 for
five contracts. Aluminum has 143 reports through June 9, 2026. Initial catalog
revision: `406d59e27de2c63addef7ee832720ebb05102e9b3ebdad9c37993532f47ac9a6`.

The report date is Tuesday, while CFTC normally releases on Friday at 3:30 p.m.
Eastern and may delay around holidays. The API data rows do not prove their
actual historical release timestamps. Each row is therefore available to this
app only from its recorded `first_seen_at`; these first-captured historical rows
are not admissible for earlier strategy decisions or walk-forward training.
The repeat capture was byte-stable and idempotent. The CFTC classification is
managed futures trader positioning, not fund flows or ETF holdings. Linked ETFs
are not yet admitted by audited price coverage or IB account qualification, and
LME aluminum is only an indicator reference. No strategy inputs, backtest,
monitored strategy, allocation, or execution authority changed.

Files: `config/positioning-recorders.json`,
`src/systematic_trading/recorders/positioning.py`,
`research/etf-research-expansion-roadmap.md`. Next: qualify a point-in-time EIA
energy supply/demand recorder, then prospective issuer holdings/shares/NAV and
ETF price/identity records; only then freeze an ETF positioning/fundamental
comparison. National PMI, corporate bond spread rights, and dated consensus
remain separate source gaps.

## 2026-10-07 - Context ridge monitored; financial-condition combinations completed

On the user's explicit instruction, `research_economic_context_ridge_v1`
(Leading + payroll/inflation context · linear model) is now Monitored, generation
1. The exact economic-response v2 CR recipe is app-owned and remains frozen until
the ETF-universe revisit. Its full report is current through October 6: all 130
historical model decisions, 795 fills, 2,705 daily values and final positions
exactly match the prior study. Nine native monitored/control runs passed. Accepted
calculation revision:
`3ac2ba32ec1413383b849c589e7ccd7d593955e4adee3c7626025a57e169cc38`.
All five monitored strategies are current and allocation-ready. Monitoring did
not alter SOTA, capital, approvals or orders; allocation control revision remains
3 and the user's pending F3 handover is unchanged.

Latest economic features are incomplete, so CR correctly abstains to capped F3
and shows a yellow notice. Future decisions from October 8 require actual app
capture before the cutoff; archive restoration cannot backdate late observations.
During the first app calculation, the required October 5 vintages finished
publishing. The publication guard rejected the older calculation; the normal
retry completed on the final input subset. Both immutable attempts are retained.

Added Treasury slopes T10Y3M/T10Y2Y, Chicago Fed NFCICREDIT and SLOOS
DRTSCILM/DRTSCIS to the app recorder and Economic Data. Published all 2,112 planned
snapshots, preserving the original 1,441 entries exactly. Batch:
`9fb6784447635430354fa0547e8787f37d0e7c69d60a62053a65b0279ff8b8b4`.
The Treasury histories omit the initial January 2, 2006 holiday; it is disclosed
as unsupported, never filled. Internal gaps remain audit failures. NFCI is a
credit composite, not a corporate bond spread; corporate-spread storage rights,
national PMI and pre-release consensus remain access gaps.

The user additionally authorized combinations of the new economic inputs per
ETF. Frozen financial v1 tests eight financial features alone and all 21 original
plus financial features, each with separate per-ETF ridge and depth-two trees.
An original-context ridge matches the augmented training rows and availability.
All tilts apply to capped F3 directly and preserve its gross, cash and positive
membership. Prices remain on audited batch
`a95bf6a48a79c338b63774a87f0b4bea21a97120ddfa5d987cb5f243ae44fbe2`;
vintages and labels obey the declared ex-ante contract with historical archive
availability limitations. No parameter or ETF search was performed.

January 2021–October 6, 2026, 5bp costs, USD, zero-interest cash:

| Recipe | CAGR | Sharpe | Calmar | Maximum drawdown |
| --- | ---: | ---: | ---: | ---: |
| Frozen context ridge (CR) | 11.000% | 1.1027 | 0.9740 | -11.293% |
| Financial-only ridge (FR) | 11.102% | 1.1057 | 0.9798 | -11.332% |
| Financial-only tree (FT) | 11.066% | 1.0992 | 0.9534 | -11.606% |
| Augmented ridge (AR) | 11.040% | 1.1029 | 0.9753 | -11.320% |
| Augmented tree (AT) | 10.901% | 1.0877 | 0.9527 | -11.442% |

FR passes the fixed retention screen but its six-month-block Sharpe and Calmar
difference intervals versus CR include zero. No mean contrast passes 5% Holm
with three- or six-month blocks; FT versus P3 passes only the twelve-month-block
sensitivity (p=0.0204), while FT fails its linear and delay hurdles. AR fails
delayed Calmar. Both trees fail replacement screens. Full-history FR Sharpe
1.0619/Calmar 0.5845 trail CR 1.0703/0.5977, with drawdown 17.13% versus 16.83%.
All model combinations have worse prediction MAE than the ETF-specific training
mean. Retain FR as research evidence, no additional monitoring or promotion.

Financial features are ready on 130/130 historical decisions and models on
70/70 evaluation decisions. Augmented/matched models remain ready 58/70; matched
ridge reproduces CR exactly. FR changes 42/70 allocations: it increases SPY in
29 months, EWJ in 23 and DBC in 18, while also reducing assets conditionally.
These are model associations, not identified causal shock sensitivities.

Completed 51 replays, eleven native validations and 27 inference jobs on all 16
logical CPUs, with three memory-bounded native lanes. F0/F3/P3/CR full-period
controls reproduce exactly. 121 distinct focused monitoring, recorder, model,
reporting and integration tests passed; Ruff/whitespace and browser checks passed.
Evidence: `var/research/economic-monitoring-20261007/` and
`var/research/economic-financial-20261007-v1/`. Protocol SHA-256:
`7744d4585a435d4a5781d84eab4de0f7757e75e7198e00de9f8db83d1cd7d4fd`.
[Findings](../research/economic-financial-2026-10-07/findings.html) and
[complete assessment / reports](../research/economic-financial-2026-10-07/assessment.html).

Next: admit an expanded ETF universe through issuer identity and audited price
coverage; build prospective issuer holdings, shares outstanding and NAV records,
then a sector activity/growth/valuation/positioning pilot. Energy balances and
futures positioning require separate source and release-history qualification.
Revisit economic combinations once that universe exists; single stocks remain
out of scope. The independent legacy `lean-history` archive import is still
retrying a connection timeout; accepted monitored reports and economic
publications are complete. This is a separate archive-ingestion follow-up.

## 2026-10-07 - Completed economic asset-response experiment

Completed the broader eleven-series experiment after fixing allocation
preparation and deferred approval. Seven leading indicators and separate
payroll/output/headline/core inflation context feed per-ETF shallow trees and
ridge models. Original daily economic vintages, completed training labels,
training-only transforms and matched sample/availability controls enforce the
declared ex-ante contract. All inputs use published audited price batch
`a95bf6a48a79c338b63774a87f0b4bea21a97120ddfa5d987cb5f243ae44fbe2`
and economic batch
`25088ea74e961b25e43a998035743d1483fe9b2e800d5253b1da3d9073f72460`.
Historical dissemination limitations remain; app first capture is October 2026.

Primary evaluation: January 2021–October 6, 2026, USD, 5bp costs, zero-interest
cash. P3 (F3 with a 45% final target cap) gives CAGR 10.778%, Sharpe 1.0811,
Calmar 0.9220 and maximum drawdown 11.690%. Leading ridge gives
10.995% / 1.0896 / 0.9702 / 11.333%; combined ridge gives
11.000% / 1.1027 / 0.9740 / 11.293%. Both pass the finite cost/delay retention
screen. Trees fail to beat their paired linear models; combined tree also fails
delayed Sharpe. Original F3 remains reported at 10.740% / 1.0765 / 0.9185.

No paired mean-return contrast passes 5% Holm for any predeclared block length.
Combined ridge versus P3 has a positive marginal Sharpe interval but a Calmar
interval crossing zero. Combined ridge versus sample-matched leading ridge
adds only about 6bp CAGR and 0.0085 Sharpe. Full 2016-onward context lowers
combined ridge Calmar (0.5977 versus P3 0.6059); leading ridge lowers both ratios.
Forecast MAE worsens with context despite its small portfolio gain. Preserve
these limitations; retain linear candidates for further evidence, no promotion.

Leading features support 66/70 evaluation decisions; combined/matched support
58/70 and abstain November 2025–October 2026. No missing CPI observation was
filled from a later vintage. Models learn different signed associations and
increase as well as decrease ETF weights, but cannot add a beneficiary excluded
by parent eligibility or spend parent cash. Country-specific fundamentals,
national PMI, consensus surprises and expanded eligibility remain untested.

All 51 price/cost/delay replays, eleven primary native checks and 30 inference
jobs completed using the 16-CPU budget. Original full F0/F3 fills, NAV and final
positions reproduce exactly. Twenty-one focused tests passed. The retained v1
attempt stopped before portfolio replays on a 1e-28 Decimal sum difference;
v2 fixes arithmetic precision only, with no model or threshold change.

[Findings](../research/economic-response-2026-10-07/findings.html),
[complete assessment and eleven reports](../research/economic-response-2026-10-07/assessment.html),
[contract](economic-response-research.md); frozen receipts under
`var/research/economic-response-20261007-v2/`. Protocol SHA-256
`bd405774bb76310d0b8ddb9e2926435740a7088ba87f1dd80a224d09ed11165c`.
No new source, monitored recipe, funding or execution authority was introduced.
The user's separately saved F3 allocation remains pending for October 7 close,
control revision 3. Next: public yield/credit/lending vintage recorders, then
prospective issuer holdings/shares/NAV and a bounded sector-fundamental pilot.
Do not tune this batch further or use manually maintained monitoring cards.

## 2026-10-07 - Leading economic panel expansion

User broadened the economic work before the three-series portfolio experiment
was frozen or run: prioritize leading indicators, exclude GDP, use ex-ante
nonlinear predictions and allow different assets to benefit or suffer. Expanded
the app recorder from three to eleven series with 1,441 verified captures (131
per series). Preserved all original 393 captures and their hashes through an
explicit additive registry migration.

Seven leading candidates: claims, permits, manufacturing hours, temporary help,
core capital-goods orders, and Philadelphia Fed future orders/employment. Four
separate context series: payrolls, manufacturing output, headline CPI and core
CPI. Regional surveys are not national PMI; a leading business-cycle measure is
not automatically predictive of asset prices. User confirmed no existing data
subscription. Continue public-source work; national PMI and pre-release consensus
remain explicit access/availability gaps, alongside upcoming credit-condition,
country and sector recorders.

Published catalog `25088ea74e961b25e43a998035743d1483fe9b2e800d5253b1da3d9073f72460`.
Readiness across 130 frozen decisions: leading group 126, context group 118,
combined group 118. Preserve unavailable readings. The conservative complete
13-month CPI window excludes ten 2026 decisions per CPI series because an
interior observation is missing; do not fill it from later history. Compare
context additions against leading models with matched training/availability
controls so differences in usable samples are not mistaken for feature value.

[Readiness report](../research/economic-leading-data-2026-10-07/assessment.html).
Frozen source, features and acceptance:
`var/research/economic-leading-panel-20261007-v2/`. The v1 attempt is retained as
incomplete after an audit adapter passed extra provenance fields to the reader;
the v2 repair did not change any source or feature formula. One transient source
404 recovered after the declared retry interval. 68 tests passed, one optional
skip; 22 real API history checks, source hashes, browser coverage and unchanged
four allocation-ready monitored strategies passed. Analytics errors cleared;
tracked revision and control revision 2 remain unchanged.

Next: implement the broader, bounded leading-only versus leading-plus-context
asset-specific tree/linear experiment on the pinned panel, with original-vintage
features, completed training labels, all-core replay, costs/delays and full shared
reports. The three-series overlay/model/study files remain an unfinished draft,
not a backtest result or registered strategy. No economic performance improvement,
promotion or funding change is claimed.

## 2026-10-07 — Economic vintage panel and revision sensitivity

The app now records ICSA (jobless claims), PERMIT (housing permits) and IPMAN
(manufacturing output), with 393 verified captures / 131 vintages per series in
**Market Data → Economic Data**. Catalog batch
`bd5668b74622858a88bdc0619ce02cc27a6f26b3d13570b55e61fea1da3c0682`
is pinned in `var/research/economic-panel-20261007-v1/input_pin.json`.

Against the frozen 130 monthly strategy decisions, five readings exceed freshness
limits (claims November 2025; permits December 2025–February 2026; manufacturing
December 2025). Preserve these as unavailable. There are 385 usable same-vintage
features; later revisions change the weakening flag in 13/129 claims, 4/127 permits
and 34/129 manufacturing measurements. Latest revised histories would therefore
change 51 flags in this fixed diagnostic. This is not a stock-return forecasting
result. No economic overlay was backtested or promoted.

Report: [economic data readiness](../research/economic-data-2026-10-07/assessment.html).
Contract: [economic vintage recorder](economic-vintage-recorder.md). The app owns
daily capture and catch-up; archive end-of-day availability and actual first capture
remain separate, with an explicit archive assumption required for historical use.
61 tests passed / one optional skip, source/API/browser acceptance passed; existing
SOTA, F3 monitoring and paper capital remain unchanged. Next freeze the small US-only
overlay, stale-data behavior and exposure/cost controls before outcome inspection.
Continue issuer holdings/shares/NAV and country/industry recorders separately.

## Treasury-bill recorder and F4 parking — 2026-10-07

Completed recorder-first BIL qualification and one predeclared F4 ablation.
Application-owned research ETF acquisition now captures issuer identity and
provider price/action evidence, audits complete coverage and revisions, verifies
ClickHouse rows/documents and commits the shared Market Data catalog. Failed
captures remain quarantined and retry after five minutes. Subsequent active-ETF
refreshes preserve the newly admitted series and its pinned storage batch.
Initial BIL coverage is 4,870 sessions, May 30, 2007–October 6, 2026; issuer
inception is May 25, 2007 and the unsupported initial days remain missing.
Published batch: `a95bf6a48a79c338b63774a87f0b4bea21a97120ddfa5d987cb5f243ae44fbe2`.
The price/action audit is single-provider reconstruction, not certification of
historical dissemination, holdings, broker eligibility or interest terms.

Frozen `bill-parking-v1` retains F1's final risky ETF weights, adds BIL only below
four positive-momentum qualifiers, caps its target at 45% and reserves at least
2% cash. BIL exits on normal monthly breadth; no ranking/model change, cap search
or F3/BIL combination. Seven primary portfolios, 25 cost/delay replays and all
seven native accounting checks passed. F0/F1/F3 decisions, fills, daily NAV and
positions exactly reproduce all 12 matched prior cost/delay controls. Used 16
Python workers and three native lanes sharing 16 CPUs.

| Full 2016–October 6, 2026 / 5bp | CAGR | Sharpe, zero reference rate | Calmar | Maximum drawdown |
| --- | ---: | ---: | ---: | ---: |
| F0 current SOTA | 9.779% | 0.9783 | 0.4425 | 22.097% |
| F1 qualifying ETFs + cash | 9.702% | 1.0339 | 0.5715 | 16.976% |
| F4 F1 + capped BIL | 9.841% | 1.0474 | 0.5856 | 16.804% |
| F3 qualifying defensive ETFs + cash | 9.931% | 1.0581 | 0.6048 | 16.420% |

F4 adds 13.9bp annualized return versus F1 at 5bp trading costs, 9.6bp at 20bp,
and 13.9bp with one extra execution session. It passes the fixed economic screen
but remains weaker than F3 overall. Eighteen decisions form only three episodes;
the largest benefit is in 2022–23, while early 2016 slightly loses after costs.
Holm-adjusted paired mean-return p-values versus F1 are 0.093/0.251/0.396 for
3/6/12-month blocks. Twelve-month ratio intervals include zero. Retain parking as
a modest cash-management component for future research, not an established alpha
improvement or replacement for F3. Cash earns zero; distributions enter through
adjusted prices; no broker cash-yield or untouched out-of-sample claim.

Assessment and seven full reports: `research/bill-parking-2026-10-07/assessment.html`.
Frozen inputs/economics/inference: `var/research/bill-parking-20261007-v1/`.
Protocol SHA-256: `4ac477e45428bf49704b28b5fcde306b9d8003fe0a510dacc544e8ac4af0f0a8`.
Relevant regression suite: 98 passed / one optional skip. Current SOTA, monitored
membership and capital remain unchanged. Next: macro release vintages and issuer
holdings/shares/NAV recorders, then a finite country/energy/sector fundamental
pilot. ETFs remain the trading boundary; no more unregistered ranking search.

## XGBoost ranking, exposure attribution and final target caps — 2026-10-07

Completed a second finite batch after the user asked to use XGBoost predictions
for top-6/8/10 selection instead of only a weight tilt. Protocol
`fallback-ranking-construction-v1` was frozen before the new outcomes: 16 primary
portfolios, 66 cost/delay/context replays and 15 registered contrasts. The model
target remains next-month adjusted USD return relative to the universe mean;
training, features and monthly model schedule were held fixed. All ranking arms
use the F3 defensive/cash fallback, the same positive 252-session eligibility gate
and later overlays. Price/volume rankings at each N and no-XGBoost-tilt controls
separate basket size, ranking and tilt removal. Top N is a maximum, never a
forced investment in rejected assets.

Common evaluation window: January 4, 2021–October 6, 2026, starting with USD 1m,
5bp trading costs, zero cash interest/reference rate. This window was already
inspected; no untouched holdout claim is made.

| Integration | CAGR | Sharpe | Calmar | Max drawdown |
| --- | ---: | ---: | ---: | ---: |
| F3 price/volume top 6 + XGBoost tilt | 10.74% | 1.076 | 0.919 | 11.69% |
| Forecast ranking top 6, no XGBoost tilt | 9.88% | 1.014 | 0.794 | 12.43% |
| Forecast ranking top 8, no XGBoost tilt | 7.69% | 0.888 | 0.626 | 12.28% |
| Forecast ranking top 10, no XGBoost tilt | 5.96% | 0.781 | 0.484 | 12.31% |
| Price/volume top 8 + XGBoost tilt | 7.46% | 0.864 | 0.616 | 12.10% |
| Price/volume top 10 + XGBoost tilt | 6.10% | 0.798 | 0.503 | 12.12% |

Forecast top 6 increases turnover from 5.87× to 7.93× annually and remains weaker
at 10/20bp and with an extra execution-session delay. Removing the XGBoost tilt
alone gives top-6 Sharpe 1.067; prediction-driven selection itself supplies no
improvement here. Average eligible-universe rank IC is 0.110 for XGBoost versus
0.233 for price/volume over 57 complete eligible months, a descriptive diagnostic.
All 15 paired mean-return tests fail the 5% Holm-adjusted threshold across
3/6/12-month block sensitivities. The six-month Sharpe-difference interval for
forecast top 6 minus F3 is [-0.189, +0.060]. Preserve the negative result;
do not replace the monitored recipe or widen its basket on this evidence.

The exposure control calibrated on 2016–2020 freezes its scale at 0.9151117.
It does not reproduce F3 protection (Sharpe 0.861, drawdown 20.40%). Matching
F3's monthly invested budget while keeping F0 composition produces almost the
same result as F3 (Sharpe 1.077 versus 1.076). Exposure timing explains much more
than defensive selection in this window, which contains only one fallback episode.
Neither result establishes future timing skill.

A separately tested 45% final target cap sends excess weight to cash. Full
2016–October 2026 F3 Sharpe changes only from 1.058 to 1.061 and CAGR from 9.931%
to 9.949%, while maximum held weight falls from 53.65% to 46.64%. Target weights
are capped at 45%; holding drift and execution gaps remain possible. Retain as a
risk-control candidate, not a demonstrated alpha improvement or an approved
portfolio change. No cap/ranking winner combination was searched.

All 130 original monthly targets reproduced exactly; full-history F0/F3 NAV,
fills and final positions match the prior study. All 16 primary native parity
checks passed. Used 16 Python workers (18.77 seconds) and three memory-bounded
native lanes sharing 16 CPUs (127.21 seconds). 39 focused tests passed. Inputs
remain the pinned audited adjusted-price batch
`9d05d12524221f562ed949926e78ba00bf126e427ee9de704ccdb0578d79655e`, with verified
model/USD artifacts and explicit historical availability/volume/FX limitations.
No new source, recorder, monitored membership, SOTA, allocation or execution
authority change. The app's previous archive-ingestion warning has cleared.

Findings and all 16 standard reports:
[research assessment](../research/ranking-construction-2026-10-07/assessment.html).
Frozen evidence: `var/research/ranking-construction-20261007-v1/`.
Next: recorder-first Treasury-bill parking and macro/issuer/industry inputs from
the roadmap. A new momentum target or ranking-specific training objective needs
a separately frozen experiment; it was not tested here. Prospective F3 tracking
and operator promotion remain separate.

## Defensive-cash monitoring and strategy lifecycle — 2026-10-07

At the operator's request, **Qualifying defensive ETFs + cash** (`research_fallback_f3_v1`)
is now the fourth monitored strategy, with a complete application-calculated shared
report through October 6. Monitoring is separate from SOTA promotion, capital and
execution authority. Existing rolling XGBoost + activity + USD remains the SOTA
and 100% paper allocation at control revision 2; no pending change was added.

The new USD replay uses pinned published adjusted histories and verified model/USD
inputs, avoiding uncertified historical currency conversion. All 130 decisions,
2,705 daily values, 795 fills and final positions match the frozen F3 study exactly.
Four USD native runs passed execution/accounting parity. Standard report Sharpe is
1.0581, Calmar 0.6042 and maximum drawdown 16.42%; its calendar/anchor annualization
is 9.9207%, explaining the small rounding difference from the study's 9.93%.
These remain retrospective results from only three fallback episodes. Prospective
monitoring starts October 8, with no prospective observations yet. CNH portfolio
comparison uses only a separate exact-date verified FX bridge; raw USD NAV cannot
be substituted for CNH. No new data source was required.

Archive now pauses ongoing app calculations and retains the complete report.
Restore replays missed signals, scheduled trades, cash, holdings and daily NAV;
allocation remains blocked until the current membership generation is fully
published. Current SOTA, funded or pending-allocation strategies must be released
from those roles before archiving. Historical artifacts without an executable
recipe remain viewable but cannot be restored by merely relabelling them.

Publication: `19bcca6e344472ec1187f95635513e7c11de43f486636f21dc6ee937a72ef099`;
acceptance evidence: `var/research/strategy-lifecycle-20261007-*` and the publication's
`usd/study_comparison.json`. Next: operator promotion/allocation if desired, followed
by the already recorded prospective, matched-exposure and recorder-first F4 work.

## Fallback implementation and first results — 2026-10-07

Completed the authorized F0–F3 batch on the active rolling XGBoost/activity/USD
baseline, with 16-core independent calculations, 19 Python replays and four
native execution-parity checks. All 130 baseline monthly target schedules
reproduce exactly. Versioned cash/defensive fallback parameters and downstream
membership/gross-budget protection now use the shared backtest and paper target
pipeline; existing definitions retain the neutral policy.

At 5 bp costs and zero cash interest, USD Sharpe improves from 0.978 to
1.034/1.058/1.058 and Calmar from 0.443 to 0.572/0.604/0.605. Maximum drawdown
falls from 22.10% to 16.98%/16.42%/16.42%; CAGR is 9.78% versus
9.70%/9.92%/9.93%. Only three fallback episodes drive these results, with gains
concentrated in 2022–23 and missed gains in the earlier episodes. Paired return
uncertainty includes zero after multiple-comparison adjustment. Retain the
active strategy; preserve challengers for further validation, with no monitoring,
capital or execution-authority change.

Full interpretation, constraints, source hashes, costs, delayed execution,
episode attribution and next steps: [fallback results](../research/fallback-results-2026-10-07.md).
Immutable artifacts: `var/research/fallback-20261007-v1/`.

F4 remains unrun: neither BIL nor SGOV has admitted published history. The next
new-data task must implement the recorder and make its audited publication
inspectable in Market Data before features or backtests consume it. Existing
audited ETF and dollar-index sources sufficed for F0–F3. Exposure-matched controls,
final portfolio caps, cash remuneration and prospective validation remain open.

## ETF research expansion proposal — 2026-10-07

The user set an ETF-only boundary for the ongoing strategy-improvement work,
with country leading indicators, better momentum/crash handling, broader asset
exposures and sector-specific activity, growth, valuation, sentiment and
positioning information as research directions. Constituent financial statements
may inform ETF signals; single-stock trading remains outside this workstream.

The [research and data roadmap](etf-research-expansion-roadmap.md) proposes staged
universe/signal comparisons against the active October 4 rolling XGBoost +
activity + USD strategy. Priorities are a separately versioned final-weight risk
contract, dated ETF holdings/issuance, macro release vintages and macro/energy
pilots, followed by validated sector financials and selected narrow industries.
Existing SEC parsing and macro score hooks do not establish an audited sector
panel. The proposal includes recorder/source priorities, availability controls,
matched benchmarks and app-owned calculations. Experiment recipes, paid sources
and acceptance tolerances remain proposals; no experiments, recorder deployment,
new tracking, promotion or allocation changes were performed in this session.

October 7 follow-up: the user requested explicit near-total cash and alternative
fallback tests. The pool code confirms that fewer than four positive-momentum
qualifiers cause the original basket to pass through, before subsequent layers.
The roadmap now prioritizes F1 qualified base weights plus residual cash, F2
cash only, F3 qualified IEF/TLT/GLD base weights plus cash, and F4 an explicitly
specified Treasury-bill ETF parking alternative, against the unchanged F0.
Zero qualifiers may target 100% cash; no minimum investment is imposed.
Cash budgets must survive downstream overlays. Missing-data/model failures are
separate blockers, with matched cash/FX economics, re-entry and fallback-episode
attribution required. This is a research specification, not a tested improvement
or a change to the active strategy.

## Active SOTA and paper allocation — 2026-10-04

The operator approved 100% Rolling 1y XGBoost + ETF activity lag-20 + USD
(`research_rolling_xgboost_1y_lag20_v1_usd_v1`) through the strategy controls.
After evidence-preserving recovery of five completed-order conflict flags and
fresh matched IB reconciliation, the app activated that allocation and SOTA
designation at 08:56:12 +08:00 on October 4 (control revision 2). The approved
handover follows October 2 close; next execution session is October 5.
This is the existing monitored version and separate USD layer, with no model
recipe change. New routing approval remains required. Prior strategy periods,
holdings, execution history and the portfolio baseline are retained.

## USD promotion decision — 2026-10-02

The operator reviewed the momentum results and selected the tested U1 USD layer
for SOTA and both monitored portfolios. The new strategy IDs append `_usd_v1`
to the original SOTA, ETF activity lag-20 and rolling one-year XGBoost IDs.
The complete original definitions remain registered and serve as matched
benchmarks and rollback parents. This decision supersedes the earlier instruction
to retain those parents unchanged.

U1 is a separate final allocation layer: per-ETF expanding ridge with short and
older momentum, 63-return volatility, and same-vintage broad-dollar changes over
21/63 valid observations. Monthly fits require 60 completed monthly labels ending
strictly before the fit close. It preserves selected assets and gross exposure,
using the tested 12% rank tilt and 3 percentage point bounds. XGBoost keeps its
existing 26 inputs and training recipe; including USD inside the trees would
require a separately versioned, matched refit comparison. No such comparison has
been run, so the integration preserves the tested separate model.

The statistical conclusion has not changed: the USD-specific U1-minus-U0 gain is
about 14 bp/year over 30 months, with an interval including zero and Holm p=1.
U1 also contains price features; its full improvement cannot all be attributed to
USD. Prospective tracking of these selected versions begins October 2, 2026.
The inherited 45% setting remains a base allocation limit; it is not a final
holdings cap. The USD layer cannot increase an inherited overweight above 45%.
The requested addition does not alter broker risk limits or increase capital.

Market Data includes USD in Historical Daily Price for published DTWEXBGS history, index
levels, 21/63-observation changes, vintage dates, missing observations and export.
The chart uses one revised vintage; historical models use their own archived
vintages. The application acquires, audits and publishes new required snapshots,
fits models and calculates complete portfolios on refresh. Daily ALFRED archives
do not certify intraday dissemination. Revised ETF histories and legacy CNH FX
retain their existing availability limitations. USD/CNH remains unhedged.

Decision and rollback contract: `config/strategy-promotions/usd-ridge-u1-2026-10-02.json`.
The existing paper policy is bound to the previous strategy ID and therefore
disables automatic approval on restart. It must be reviewed and re-enabled for
the new version through the normal controls; live remains disabled. Paper/live
proposal calculation uses the same published USD model receipt as monitoring and
requires its ETF batch to match the audited decision inputs.

## Momentum horizon, membership and USD round — 2026-10-01

User authorized the revised research plan and all-core backtesting. Completed
102 USD replays: 24 new SOTA recipes, two parent clocks, two benchmarks, two
other-parent controls and four USD transfers, each at 5/10/20 bp per traded dollar.
All 34 base-cost portfolios plus two high-cost stress cases pass native LEAN
parity. Monthly targets reproduce all three monitored parents exactly across
129 decisions. No monitored strategy, execution policy or live setting changed.

Current monthly SOTA returns 9.17% net USD CAGR in this accounting scenario.
One/two-week momentum gives 4.17%/5.61%; the older-window blend gives 6.95%.
All four trend/skew gates trail the parent. Membership C1/C2 reduce annual cost
from 31.8 bp to 26.0/28.5 bp, but CAGR falls to 8.32%/8.41%. These are USD
adjusted-unit research results, not the existing CNH-accounting dashboard series.

Downloaded 92 ALFRED DTWEXBGS vintages and the Fed's revised daily history.
Audited same-vintage snapshots and verified analytical readback before publication
under `governance/usd-broad-index`, batch
`ddb5624ba023c71b9ca41ff0571318eb48f390ad4131ab20858d7eaafdae006b`.
The fixed 60-month ridge training requirement leaves April 2024–September 2026
for evaluation. USD adds 13.9 bp/year versus the matched price-only model;
the marginal six-month-block 95% interval is [-11.4, 33.7] bp, Holm p=1 over
the frozen 58-comparison family. Selected same-data transfers add 13.1/14.2 bp
on activity/rolling parents; these are correlated descriptive evidence.
Retain the USD hypothesis for discussion; no candidate clears promotion criteria.

Risk finding: the inherited 45% cap applies before pool reallocation; the
monthly parent reached 54.68% held weight and the weekly parent 61.52%.
A separately versioned final-weight constraint is needed before advancement.
Parent volume features remain legacy normalized proxies; audited prices are
revised vintages, and ALFRED availability is daily archive evidence with a
conservative prior-day cutoff. Legacy historical USD/CNH was excluded, so no
full historical CNH bridge is claimed. No prospective performance is claimed.

Full results: [review report](../research/momentum-results-2026-10-01.md).
Artifacts: `var/research/momentum-20261001-v1b`; earlier failed engineering
attempts and the transfer-selection correction are preserved. Tests: 48 passed,
one environment-dependent PostgreSQL integration test skipped. Source checks
and native parity retain paper-first controls.

## Rolling one-year XGBoost with lag-20 selected for app tracking — 2026-09-27

The user selected a third tracked candidate: `research_rolling_xgboost_1y_lag20_v1`.
The original rolling study had no activity overlay; the new definition adds the
unchanged lag-20 allocation overlay after XGBoost and the remaining SOTA steps.
The application owns monthly causal fitting, portfolio calculations and the full
shared report. All 129 models exactly match the study, and five native runs pass
parity. Matched activity-only and XGBoost-only controls appear in the report.

Full-history annualized return is 10.093%, Sharpe 0.9675, maximum drawdown -15.336%
through September 25, versus SOTA 9.656%, 0.9492 and -15.055%. This is historical
reconstruction selected after reviewing results; prospective tracking starts
September 28 with zero observations at publication. SOTA and existing activity
results are unchanged. No promotion, broker execution or paper-policy change.
See [strategy specification and initial acceptance](rolling-xgboost-lag20-tracking.md).

## Rolling tree, forest and XGBoost investigation — 2026-09-27

Completed all 41 native LEAN runs with unchanged parity. Monthly one-year
XGBoost/forest return 15.88%/15.75% CAGR from 2023 versus deployed frozen SOTA's
14.94%; primary six-candidate adjusted p=0.014/0.020 (63-session blocks).
However, frozen XGBoost/forest return 15.72%/15.68%, and tree-free SOTA returns
15.49%. Rolling adds only 0.159/0.063 annual percentage points versus the same
frozen model family; intervals include zero (adjusted p=0.529/0.692). Two-year
ensembles lag their frozen counterparts. Cost, delay and seed checks retain
the one-year ensemble gains versus SOTA, but gains are concentrated in 2025–26.
Long-history forest/XGBoost CAGR 9.97%/9.94% versus reconstructed SOTA 9.63%;
long adjusted p=0.068/0.108. No uniform stress-period improvement or clean
evidence for rolling refitting itself. Retain SOTA; future evidence should compare
fixed frozen and rolling ensemble recipes prospectively.

All 16 logical cores were used for independent fits; eight process workers ran
isolated two-CPU LEAN simulations. Published audited inputs, pinned FX/model
hashes, completed-label embargo and fixed portfolio rules are retained. Revised
vintages, fixed-universe selection and uncertified legacy FX remain limitations.
Archived 52,749 NAV/metric observations, six documents and 41 native receipts.
See [findings, protocol and replay](rolling-model-research-2026-09-27.md).
Calculations were a finite application job; no tracked membership, promotion,
paper policy or execution authority changed.

## App-owned tracked calculations — 2026-09-26

The application now owns the entire calculation lifecycle for monitored executable strategies. `config/strategy-monitoring.json` selects native LEAN with Python parity (default) or the application's isolated Python engine. New audited inputs/definitions trigger signal, monthly rebalance, daily NAV, held-weight and latest indicative-target calculations; unchanged revisions are reused. Complete results and their matched benchmarks publish atomically to ClickHouse. **Refresh calculations** wakes the application worker. The Codex heartbeat was deleted and its review script retired. `AGENTS.md` and the continuous research playbook explicitly prohibit agent-scheduled strategy calculation.

Both SOTA and ETF lag-20 use the same full report, including risk parity on the matched ETF universe, URTH, current SOTA, period metrics, drawdowns, holdings contributions, signal attribution, current allocation and complete decision diagrams. SOTA attribution uses risk parity; lag-20 attribution uses SOTA. History spans 2016 onward: pinned causal annual trees before 2023, then the unchanged deployed frozen model. The old 2023 card was the frozen-model companion, not a price-data boundary. The new history is a disclosed reconstruction and differs from the earlier all-years annual-refit experiment.

User decision remains **track, do not promote**. Forward observations begin 2026-09-28; historical results are not relabelled as prospective evidence. Only published audited prices are used. Legacy FX remains explicitly uncertified through September 24; validated direct IB USD/CNH close evidence supports September 25. Historical price vintages remain a limitation. Protocol and engine configuration: [app-native lag-20 tracking](etf-activity-lag20-tracking.md).

## Superseded initial ETF lag-20 observation workflow — 2026-09-26

The initial frozen card remains historical evidence in `config/etf-activity-lag20-tracking-v1.json` and ClickHouse `research-tracking/etf-activity-lag20-v1` (935 paired historical NAV points). Its daily Codex review automation has been deleted. The application calculation and common report above supersede this workflow; do not restart its agent scheduler or treat its archived card as the current strategy.

## Audited-input rerun — 2026-09-26

Retain current SOTA. The pinned audited batch has now been used for 24 native LEAN runs, all passing parity, covering 2016-01-04–2026-09-24 with causal annual fits plus actual-frozen-model companions from 2023. Baseline CAGR/Sharpe 9.84%/0.956; early signed constituent activity 9.82%/0.955, IR -0.172; constituent concentration IR -0.289. Earlier allocation/selection and joint residual trees do not establish added value. The fixed ETF lag-20 observation candidate reaches 9.99%/0.966, IR +0.285, but its 63-session family-adjusted p=0.574 and uneven period performance do not justify promotion. Candidate-specific audited cost/delay work remains before any lag-20 promotion review.

The stricter supported-raw/identity rules qualify only 32/129 monthly decisions, first 2023-08-01. Earlier months are neutral fallback, not a decade of constituent evidence. There are 551 matched scatter dates starting 2023-07-17; unsmoothed derivatives are near zero, with a modest smoothed 20-session relationship that has not improved the strategy. Do not lower coverage rules after seeing these results. Resolve historical issuer/raw-price gaps in a new audited batch before extending constituent evidence.

Future price research must read published audited continuous histories with pinned batches, verified hashes and explicit adjustment/volume bases, as required by `AGENTS.md` and the continuous research playbook. Provider archives are acquisition/audit evidence only. Auditing does not supply missing point-in-time vintages, complete delistings or certified FX. The unchanged legacy FX and assumed holdings-publication lags in this frozen rerun remain disclosed limitations.

Evidence: [audited rerun findings](audited-research-rerun-2026-09-26.md); `D:/systematic_trading_data/lean/research/audited-rerun-20260926-v1/`. ClickHouse contains 11,862 new observations and 22 documents across feature/result/review publications with exact payload readback; 24 native receipts are registered in PostgreSQL. Prior studies remain reproducible legacy evidence; the production model and monitoring-reader contracts are unchanged.

## Data-governance hold — 2026-09-26

The frozen ETF inputs used in the recent studies contain adjustment/source
boundary inconsistencies against a consistently collected new Yahoo vintage.
For HYG on 2026-05-26, the old snapshot implies -1.6528% versus +0.3379% in the
new governed series (1.9907 percentage points). That boundary coincides with
`sqlite_price_bars` changing to `platform_market_data_store`; SPY and LQD also
differ there. EWH has a separate discrepancy on 2026-04-30. Preserve prior
results as reproducible evidence of the old inputs, but rerun baseline and
candidate comparisons on pinned governed data before any promotion decision.
The identity audit also found older CSVs containing multiple economic issuers
under reused tickers (including NET/WMS/TXG). Recent price agreement does not
validate their earlier eras. Policy v2 quarantines periods before the current
provider listing boundary, or a conservative preferred-source identity floor
when that metadata is absent. Historical constituent research must map dated
issuer episodes rather than apply the current ticker's identity retrospectively.
The first governed build was quarantined before publication; its joined rows
are not accepted inputs. Original historical sources remain available for review.

No new strategy is elevated. See `docs/price-governance-2026-09-26.md`.


## Latest evidence — 2026-09-26 ten-year constituent follow-up

Retain current SOTA. The earlier January 2023 signal cutoff was a completeness
limit, not a deliberate short evaluation window. New dated IVV holdings and
archived public stock histories support 2016-01-04–2026-09-24: 122 of 129 monthly
decisions pass the unchanged primary 95%-value/70%-names rule. The 2020 and 2022
stress periods now have constituent observations. Histories remain revised,
publication lags are assumed, and IVV is a same-index proxy only for SPY.

Twenty-two long LEAN runs use annual expanding base trees to avoid future-label
leakage from the deployed pre-2023 fitted model. Baseline CAGR/Sharpe is
9.64%/0.932; early signed activity 9.68%/0.936/IR +0.158 trails the matched price
control 9.69%/0.937/+0.190. Its gain is 3.4bps CAGR, with a confidence interval
including zero and family-adjusted p=0.813. Joint residual-tree IR is +0.218
versus baseline but only +0.039 versus the price-only tree; concentration is
negative (-0.232). Selection changes three decisions and loses slightly. Early
signed activity worsens 2022. The four-run actual frozen-model companion has a
recent signed-activity IR +0.429 versus SOTA, only +0.105 versus price control,
and no statistically established gain. No promotion or trading-policy change.

The Market Data page now exposes the previously hidden ClickHouse research
archive, including stock bars, dated holdings, features and results. Added
2,298,993 current-provider stock observations, 85,050 holding rows and 7,595,897
public archived observations with exact readback. Final long-study features,
models and labels total 16,352 records; results/contrasts total 366. All 26
successful native receipts are registered. Public-source overlaps are preserved
as separate histories, not inserted into the canonical production daily bars.

Guide and replay: `docs/constituent-tenyear-research-2026-09-26.md`. Remaining
work is ETF-specific identity/publication quality and prospective validation of
fixed candidates, not further tuning on this inspected sample. Full suite 616
passed/51 optional skips; research/LEAN/browser lint, charts and browser checks
passed. Existing IB Gateway health remained unavailable during dashboard startup;
broker settings, orders and approval policy were not changed.

## Production Research Rule

Research is now part of a controlled research-to-paper-to-live pipeline. New candidates must compare against the current SOTA, use point-in-time data, record reproducible artifacts, and pass the promotion gates in `docs/industrial-platform-plan.md` before paper or live use.

## Alpha Factory Direction

The next research operating model should treat each alpha or factor as a versioned, independently observable contributor rather than only storing monolithic strategy runs. Before risk-parity-style alpha weighting is promoted, add contracts for factor identity and lineage, point-in-time signal values, theoretical factor returns, realized portfolio contribution, turnover/cost/capacity, correlation and covariance estimates, allocation weights, and retirement or rollback state.

Portfolio attribution should remain layered: strategy backtest NAV versus actual account NAV measures implementation divergence; reference-fill versus actual-fill PnL measures execution quality; factor-level theoretical and realized contribution explains which alphas earned or lost the portfolio result. Factor weights must be reproducible artifacts with concentration, correlation, liquidity, and regime-stability limits, not an unconstrained inverse-volatility calculation.

Use `.agents/skills/continuous-research-loop.md` for recurring challenger research and `.agents/skills/strategy-promotion-control.md` for promotion decisions.

## Current SOTA

September 26 earlier-integration follow-up: **retain current SOTA**. Nineteen
native LEAN runs test the selected signed-activity/breadth signals in earlier
allocation, pool selection and a shallow residual tree, with matched price-only
controls. Post-2023 earlier signed allocation is effectively identical to late
(14.77% CAGR / Sharpe 1.299 / IR +0.262); price-only early remains stronger
(14.79% / 1.301 / +0.301). Signed selection changes no weights or trades: SPY is
already held on 39/44 qualified dates and the other five have neutral/negative
signed scores. Breadth selection changes one decision and loses return.
The joint tree actually branches on stock breadth/signed activity, but 2025-onward
CAGR 18.84% / Sharpe 1.467 / IR -0.876 trails SOTA 19.03% / 1.474 and the price-only
tree 18.89% / 1.471. Twenty monthly model decisions begin February 2025; 19 change
allocations. Models have just 23/35 training months; future labels are excluded
and runtime features contain no outcome records. All samples were previously
inspected, so chronological fits are not an untouched holdout. Earlier placement
does not repair missing delistings, assumed availability or a U.S.-proxy-only
universe. Sources, four models, training labels, results and native receipts are
archived; no promotion. Next: ETF-specific constituent panels and fresh data
before a broader selection test. See
[earlier-integration evidence](constituent-integration-research-2026-09-26.md).

September 26 constituent follow-up: **retain current SOTA**. Five fixed stock
signals, their equal-weight primary composite, a price-only control and declared
robustness checks completed 15 native LEAN runs with unchanged parity. Historical
ITOT stocks guide only the SPY sleeve; they are a broad U.S. proxy, not exact SPY
or foreign-ETF membership. Full-period (2019-10-01–2026-09-24) primary CAGR
8.49% / Sharpe 0.782 / IR -0.394 versus SOTA 8.52% / 0.784. Concentration
acceleration IR -0.507. The 95%-value/70%-name complete-history rule first passes
January 2023, leaving 44 eligible monthly decisions and 33 composite target
changes. There is no constituent evidence from COVID/2022. Post-2023 primary
IR -0.540; signed activity has sample IR +0.262 but lags the price-only control
(+0.299), and its family-adjusted p=0.831 does not support inclusion. Do not
flip signs or refit weights on this reused history. Costs, delay, size and coverage
checks do not rescue the primary. All feature/results evidence is in ClickHouse
and native runs are registered; historical availability remains uncertified.
See [results and the constituent research plan](constituent-signals-research-2026-09-26.md).
Next: actual ETF-specific identities/holdings and earlier delisted histories;
then separately declared downside breadth, internal dispersion, filing-time
fundamental breadth and genuine issuance-confirmed crowding. No new recurring
job or paper/live strategy change.

September 26 flow/concentration research: **retain current SOTA**. Nineteen native
LEAN runs (17 predeclared plus two labeled post-hoc stresses) compare the current
12-ETF stack with activity-share acceleration, direction/Hurst/HHI/volume
ablations, a literal exit gate and parameter neighbors. Over 2013-04-01 to
2026-09-24, the predeclared primary returned 9.06% annually / 0.919 Sharpe versus
SOTA 9.11% / 0.924. A 20-session neighbor returned 9.28% / 0.935 and survived
matched higher-cost and delay checks, but full-period family-adjusted p=0.354
and weak neighborhood consistency do not support promotion. Retain that fixed
variant for observation; it was selected after results. The literal gate held
64.8% cash and returned 2.90%. Historical actual net flows, shares outstanding,
holdings and certified point-in-time constituent-sector membership remain absent; activity is not net inflow.
All runs passed unchanged parity and remain research-only. See the
[research report and data plan](flow-concentration-research-2026-09-26.md) and
`D:/systematic_trading_data/lean/research/flow-concentration-20260926-v3/`.
These numbers are a fresh adjusted-CNH LEAN comparison, not a recertification of
the older canonical artifact below. Next: timestamped net-issuance data and an
untouched prospective observation period, not more optimization on these dates.

Sector-HHI follow-up: daily Yahoo price/volume history for all eleven sector
SPDRs and SPY is now frozen separately under
`D:/systematic_trading_data/research/sector-hhi-20260926-v1/` (research only).
The 1,823 common signal dates, 2019-01-02–2026-04-02, show weak SPY return
correlations with share-volume HHI (+0.075/+0.115/+0.093 at 20/60/120 sessions)
and almost zero correlations with its daily first/second differences.
Smoothing does not establish an acceleration effect; period and dollar-volume
checks weaken the level relationship. These are descriptive overlapping-label
plots, not a new LEAN backtest or a promotion. ETF activity is not full-sector
turnover or investor net flows; historical adjustment vintages remain
uncertified. See [plots, methods and findings](sector-hhi-correlations-2026-09-26.md).

Underlying-stock follow-up: the public-data pilot now uses 95 historical monthly
ITOT equity snapshots, 3,267 populated stock histories and sector aggregates of
the stocks' own volumes/returns. It has dated sector cohorts, a modeled 45-day
publication lag and explicit missing/identity coverage, rather than today's
constituents applied to all past dates. However, only 139 common signal dates
(2025-09-15–2026-04-02) pass the 95%-value/70%-name coverage rules and have all
forward horizons observed. Raw first/second differences remain near zero in
that sample; its length and overlapping labels preclude a stable market-wide
conclusion. The longer observed-subset sample has material missing/delisted
history. The stock/fund histories and computed aggregates are archived under
ClickHouse `sector-research/<dataset>/` source prefixes. Keep SOTA unchanged.
See [underlying-sector evidence and storage guide](underlying-sector-hhi-2026-09-26.md).

September 26 audit: historical results below are retained as prior research
artifacts, not re-certified after the timing/data corrections. Missing source
vintages, fixed-universe survivorship and legacy FX lineage remain limitations.
The pre-2023 tree is fitted; post-2023 has been used repeatedly for strategy
selection and is not an untouched holdout. The new LEAN adjusted-CNH-unit scenario
has separate economics and artifacts; it does not overwrite these numbers or
promote a replacement. See [audit findings](platform-audit-2026-09-26.md) and
[LEAN workflow](lean-backtesting.md).

Paper operations now include separately tagged initial-allocation and 2 percentage point drift-maintenance proposals. Monthly signal calculation is preserved; intraday TWAP timing and additional turnover are not represented in the existing monthly benchmark. Keep attribution separate and validate execution/cost effects before live promotion.

### Original parent record — superseded by the October 2 USD version

- Name: SOTA: price/volume top 6 + technical tree + relative/adaptive
- Promoted on: 2026-05-26
- Registry: `systematic_trading.research.strategy_catalog.legacy_sota_definition`; `current_sota_definition` now returns the USD version described above.
- Backtest hurdle: future candidates should compare against the current USD SOTA and preserve this parent as a matched control.
- Canonical artifact folder: `var/backtests/sota_current/`
- Model HTML: `var/backtests/sota_current/sota_model.html`
- Promotion source artifact: `var/backtests/monthly_allweather_sleeve_variant_floor_search_20260525/`
- Prior SOTA artifact: `var/backtests/sota_current/history/2026-05-17_sota_dynamic_sleeve_commodity_guard_55/`

## Original Parent Model Summary

The original parent uses the expanded multi-asset ETF universe and static monthly rebalancing. The current SOTA appends the USD layer described above to this stack:

- Base: monthly multi-asset ETF universe, 63-bar inverse-volatility risk parity, 45% base weight cap before subsequent reallocation, 2% cash reserve.
- Pool filter: rank assets using 63/126/252-bar price momentum and 21/126-bar volume pressure; keep the top 6, require at least 4 selected assets, require positive 252-bar momentum, and reallocate residual weight.
- Technical tree: frozen pre-2023 regression tree, max depth 3, min leaf 25, trained on 1,572 in-sample asset-month observations with MACD, Bollinger, RSI, price trend, volume pressure, drawdown, valuation, and macro features. Tilt is 16%, with active changes capped at 6% per ETF.
- Relative momentum: 20/60-bar relative momentum overlay, 12% calm and 12% risk tilt, with active changes capped at 5% per ETF.
- Adaptive trend: 63/126/252-bar trend and volume/rebound/volatility-shock gates with weak, neutral, defensive, and rebound scaling.
- Benchmark: the canonical folder includes a benchmark-only run using the same multi-asset universe and static monthly scheduler.

Canonical results versus benchmark-only multi-asset risk parity, 2012-01-03 to 2026-04-29, split 2023-01-01:

| Window | Ann. Return | Sharpe | Calmar | Max DD | Alpha vs Benchmark | Information Ratio |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Full | 9.10% | 0.95 | 0.65 | -14.11% | 134.60% | 0.63 |
| In-sample | 6.89% | 0.77 | 0.49 | -14.11% | 54.07% | 0.49 |
| Out-of-sample | 16.92% | 1.48 | 2.00 | -8.46% | 28.57% | 1.13 |

Stability note: this candidate was promoted because it is cleaner than the high-OOS all-weather sleeve after penalizing weak in-sample evidence. The OOS/IS Sharpe ratio is still high at about 1.92, so it should be treated as the current best production candidate rather than a final answer to the stability objective.

## Workflow Rule

Use `scripts/export_sota_artifacts.py` to regenerate the canonical SOTA folder after a promotion. Use the multi-asset research scripts for new challengers; use legacy `scripts/compare_trend_signal.py` only for old single-basket diagnostics or to quantify value added versus the original beta sleeve.

The comparison artifacts include model structure diagrams for the SOTA and candidate:

- Layer diagram: data, rebalance schedule, base beta sleeve, overlays, final targets.
- Decision tree: the gating and transformation logic used by each model.
- HTML reports shade the out-of-sample region and mark the split date when a split is provided.

## Short-Horizon Relative Momentum Tests

Artifacts:

- `var/backtests/relative_momentum_20_40_signal_2012/`
- `var/backtests/relative_momentum_20_60_signal_2012/`
- `var/backtests/relative_momentum_40_60_signal_2012/`
- `var/backtests/relative_momentum_20_40_60_trend_rank_2012/`
- `var/backtests/relative_momentum_20_60_tilt_grid_2012/`
- `var/backtests/relative_momentum_20_60_tilt20_2012/`

Results versus prior 126/252d SOTA, 2012-01-03 to 2026-04-29, split 2023-01-01:

| Candidate | Full Alpha vs SOTA | In-Sample Alpha vs SOTA | OOS Alpha vs SOTA | OOS Sharpe Delta | OOS Max DD Delta |
| --- | ---: | ---: | ---: | ---: | ---: |
| Relative momentum 20/40d, 12% tilt | -2.31% | -1.39% | 0.16% | -0.00 | 0.02% |
| Relative momentum 20/60d, 12% tilt | -0.09% | -0.42% | 0.36% | 0.00 | 0.05% |
| Relative momentum 40/60d, 12% tilt | -1.29% | -0.80% | 0.24% | -0.00 | 0.06% |
| Three-horizon trend rank 20/40/60d, 12% tilt | -0.89% | -0.30% | -0.09% | -0.00 | 0.06% |
| Relative momentum 20/60d, 20% tilt | 1.09% | -1.02% | 1.47% | 0.01 | 0.03% |

The 20/60d shorter-horizon pair became a prior registered SOTA and remains part of the current promoted stack at a more restrained 12% calm / 12% risk tilt. A 25-case tilt grid ranked 20% calm / 20% risk tilt first by OOS alpha. It still trailed the MSCI World proxy by 0.87% OOS, versus the prior 126/252d SOTA trailing URTH by 2.34% OOS, so future work should continue using URTH as an external benchmark check.

## Latest Country-Factor Research

Added `CountryCompositeFactorOverlay` for country ETF allocation research. It can blend:

- Price trend: 63/126/252-bar relative trend ranks.
- Volume pressure: up-volume share and signed volume acceleration.
- Mean reversion: 21-bar reversal and 63-bar moving-average deviation.
- Optional valuation score maps where positive means cheaper or more attractive.
- Optional macro-growth score maps where positive means stronger country growth.

Artifacts:

- Diversified price-trend candidate: `var/backtests/country_factor_trend_only_2012/`
- Balanced multi-factor candidate: `var/backtests/country_factor_signal_2012/`
- Aggressive US macro-prior candidate: `var/backtests/country_factor_macro_us_2012/`

Results versus prior 126/252d SOTA, 2012-01-03 to 2026-04-29, split 2023-01-01:

| Candidate | Full Alpha vs SOTA | OOS Alpha vs SOTA | OOS Sharpe Delta | OOS Max DD Delta |
| --- | ---: | ---: | ---: | ---: |
| Country factor, 63/126/252d trend only, 20% tilt | 0.10% | 1.19% | 0.01 | 0.00% |
| Balanced trend/volume/mean-reversion default | -0.87% | -0.54% | -0.01 | 0.08% |
| Aggressive US macro prior, 100% macro weight, 100% tilt | 213.16% | 27.62% | 0.17 | -4.15% |

MSCI World proxy check using URTH in CNH:

| Candidate | Full Alpha vs URTH | OOS Alpha vs URTH |
| --- | ---: | ---: |
| Country factor, 63/126/252d trend only, 20% tilt | -163.54% | -1.16% |
| Aggressive US macro prior, 100% macro weight, 100% tilt | 49.51% | 25.28% |

Promotion note: these country-factor candidates were not promoted. The diversified trend-only country factor is a credible challenger but only modestly improves out-of-sample and is weaker in-sample. The aggressive US macro-prior candidate beats URTH, but it is mostly a persistent US overweight and uses a static score map across history. Treat it as a benchmark-aware stress case until point-in-time macro and valuation tables are added to the SQLite data contract.

## Signal Library And Decision Tree

The code-backed signal library is in `systematic_trading.signals.library`; the human-readable table is `docs/signal-library.md`. Decision-tree runs also write `signal_library.md` and `decision_tree_training.json` in their output directory.

Decision-tree candidate:

- Artifacts: `var/backtests/decision_tree_signal_tilt20_2012/`
- Training sample: 655 in-sample asset-month rows, ending before the 2023-01-01 split.
- Features: 16 signal-library features from that run, covering trend, mean reversion, volume, risk regime, valuation score, and macro-growth score. The library now also includes the promoted 20/60d momentum features for future training runs.
- Model: max-depth 3 regression tree, min leaf 25, target is next-rebalance asset return minus cross-sectional basket mean.
- Learned first split: `macro_growth_score <= 0.5`, then short momentum, extended momentum, and volatility ratio.

Results versus prior 126/252d SOTA, 2012-01-03 to 2026-04-29:

| Candidate | Full Alpha vs SOTA | OOS Alpha vs SOTA | OOS Sharpe Delta | OOS Max DD Delta |
| --- | ---: | ---: | ---: | ---: |
| Decision tree, depth 3, 20% tilt | 29.00% | 0.50% | 0.01 | 0.08% |

MSCI World proxy check using URTH in CNH:

| Candidate | Full Alpha vs URTH | OOS Alpha vs URTH |
| --- | ---: | ---: |
| Decision tree, depth 3, 20% tilt | -134.64% | -1.84% |

Promotion note: do not promote the decision tree yet. It helped versus the prior 126/252d SOTA OOS, but the OOS edge was small, the tree uses a static macro score map, and it still trails URTH. It is useful as an interpretable research candidate and a framework for point-in-time macro/valuation data once those tables exist.
